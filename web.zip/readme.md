## Quaranta

Quaranta1 provides two click, two factor authentication to publicly accessible FileMaker Servers for executives using their own iPads2.

### iPad Device Authentication Suite

Quaranta is a suite of three components that include 1) an iOS app that provides the hardware ID – the Client App, 2) a Web service that authenticates – the Web Service Gateway, and 3) the Firewall Queue that is managed by the Web Service. The Windows Firewall allows devices that have been verified to access the FileMaker Server’s ports 443 and 5003.

1. The Client App asks the Gateway to open the Firewall by providing credentials

2. The Gateway checks the credentials to make sure they are valid

3. If the credentials are valid the Gateway creates two entries in the Firewall Queue, the first entry is to open the ports, and then second entry is to close ports for that user after 2 hours

### Installation
* Install [Java SE Runtime Environment 7]( http://www.oracle.com/technetwork/java/javase/downloads/java-se-jre-7-download-432155.html)
* Install [Microsoft Visual C++ 2008 Redistributable Package (x86)](http://www.microsoft.com/en-ca/download/details.aspx?id=29)
	* Install to OpenSSL binaries (/bin) folder
* Install Telnet Client
	* pkgmgr /iu:"TelnetClient"
* Install [Notepad++](http://notepad-plus-plus.org/download/)
* Install [Win32 OpenSSL v1.0.1e Light](http://slproweb.com/download/Win32OpenSSL_Light-1_0_1e.exe)
* Install [Git](http://msysgit.github.io)
	* install default components
	* Choose `Run Git from the Windows Command Prompt`
	* Choose `Checkout as-is, commit Unix-style line endings`
* Install Quaranta
	* delete contents of f:\webroot\csimobile.rbccm.com
	* PROD RBC git download zip of https://github.com/neocodesoftware/quaranta.git f:\webroot\csimobile.rbc.com
	* enter github credentials
	* PROD set the app/config/app.php 'debug' flag to false in production environment 
	* DEV set the app/config/app.php 'debug' flag to true in development environment 
* Install IIS - ROLE = Web Publishing
	* In IIS click on the SERVERNAME (not Default Site)
	* Edit Feauture > Default Document
	* Add index.php so all sites will inherit
* Set Web Root
	* In Sites > Default Web Site > edit site
	* PUBLIC Webroot f:\webroot\csimobile.rbccm.com\public
* Install IIS - ROLE > Role Services >  Web Server > Application Development > CGI
	* In Server Manager > Roles > Web Server (IIS)
	* Scroll down in the right pane to Role Services
	* Click Add Role Services and choose "CGI"
* Install IIS - ROLE > Role Services >  Web Server > Security > IP and Domain Restrictions
	* In Server Manager > Roles > Web Server (IIS)
	* Scroll down in the right pane to Role Services
	* Click Add Role Services and choose "IP and Domain Restrictions"
* Install [IIS URL Rewrite Module](http://www.microsoft.com/en-ca/download/confirmation.aspx?id=7435)
	* Add Blank Rule - Rule 1
	* Requested url = matches pattern & Using = regular expression
	* Pattern ^ <- just ^
	* uncheck ingore case
	* Conditions - logical group - match all
	* {REQUEST_FILENAME} is not a directory
	* {REQUEST_FILENAME} is not a file
	* uncheck track capture
	* Action - action type = rewrite
	* rewrite url = index.php
	* check append query string
	* uncheck log written url
	* check stop processing rules
	* save
* Change FileSystem (NTFS) Security on folder
	* f:\webroot\csimobile.rbcc.com
		* for RBC Confirm (give) IIS_IUSR group Read & Exe, List, Read
		* on Quaranta.neocodesoftware.com give EVERYONE 
	* f:\webroot\csimobile.rbcc.com\app\storage\
		* Give IIS_IUSR group MODIFY permission
		* on Quaranta.neocodesoftware.com give EVERYONE 
		* change Advanced Permissions, Change Permission `Replace all child object permissions with inheritable permissions...`
		* apply inheritance
	*  f:\webroot\csimobile.rbcc.com\app\database
		* Give IIS_IUSR group MODIFY permission
		* on Quaranta give EVERYONE MODIFY permission
* Install FileMaker Server with FileMaker PHP with IIS enabled
	* DO NOT UPDATE JAVA - skip the update if asked	
	* Update PATH variable with C:\Program Files\FileMaker\FileMaker Server\Web Publishing\publishing-engine\php\
	* OPTIONAL - Test - http://IP-ADDR/fmi-test/phptest.php
* Configure Server Manager > Roles > Web Server > IIS > [Server Name] > Sites > Default Web Sites > Handler Mappings
	* Double click FMIPHP
	* Click Request Restrictions
	* Choose Verbs tab
	* Enter for one of the following verbs
		* GET,HEAD,POST,PUT,DELETE
	* Click OK
	* Put quotes " around the executable path
		* "F:\Program Files\FileMaker\FileMaker Server\Web Publishing\publishing-engine\php\php-cgi.exe"
	* When asked if you want to make FastCGI an application say "no"
* Ensure PHP has enabled the following extensions
	* edit F:\Program Files\FileMaker\FileMaker Server\Web Publishing\publishing-engine\php\php.ini
	* readline <- not on the quaranta server
	* extension=php_curl.dll
	* extension=php_pdo_sqlite.dll
	* extension=php_openssl.dll
	* extension=php_mbstring.dll
	* extension=php_fileinfo.dll
* Install [PHP Composer](http://getcomposer.org/)
* Install Quaranta dependencies:
	* `composer install -d c:\inetpub\wwwroot\`
	* The c:\inetpub\wwwroot\vendor should be installed if not - check dependency errors
		* C:\inetpub\wwwroot\app\config\app.php
		* C:\inetpub\wwwroot\composer.json
* Install [Sqlite](http://www.sqlite.org/download.html)
	* unzip and copy sqlite3.exe to C:\Windows\System32
* Initialize database
	* sqlite3.exe c:/inetpub/wwwroot/app/database/production.sqlite vacuum;
* Setup the database:
	* Check connection config in `app/config/database.php`
	* Run `php c:\inetpub\wwwroot\artisan migrate:install`
	* Run `php c:\inetpub\wwwroot\artisan migrate`
	* Run `php c:\inetpub\wwwroot\artisan db:seed` to generate the initial user (u: `admin@quaranta.com` p: `admin@quaranta.com`)
	* OPTIONAL Run `php artisan password:reset` to specificy a better admin password
* Allow the Computer Admin account to Run Batch Jobs for the Task Scheduler
	* Click Start, type "gpedit.msc"
	* \Computer Configuration\Windows Settings\Security Settings\Local Policies\User Rights Assignment
	* Log on as a batch job
	* Add Current Administrator user
	* use "gpupdate /force"
* Setup the Queue manager
	* Create task in task scheduler
	* Task name Quaranta Queue
	* Program "F:\Program Files\FileMaker\FileMaker Server\Web Publishing\publishing-engine\php\php.exe"
	* Arguments `artisan fque:process`
	* Start in `F:\webroot\`
	* Schedule Daily
	* Repeat Every 1 minute
	* Kill task after 5 minutes
	* Run whether user is logged in or not
		* Check `Do not store password.`	
* Setup Quaranta OTA
	* Configure MIME TYPE: Open IIS Manager. Right click 'Server(local computer)'
		* Select Properties click 'MIME Types' Click 'New...'
		* .IPA   - application/octet-stream 
		* .PLIST -  application/x-plist
		* .mobileprovision - text/plain
	* Working directory: c:\inetpub\wwwrooot\public\quaranta 
	* We need to Search and replace http://192.168.1.92:9000/ with https://fm.sterbccm.com/quaranta/ in two files:
		* Quaranta.plist
		* index.html 
* Ensure that health check is installed
	* As well, I spoke to Kevin and he mentioned that he installed healthcheck back then, but looks like 
        * someone removed it - this HAS to be there so please don't remove it
        * https://fm.sterbccm.com/healthcheck/healthcheck.html
* Install Firewall Service Role
* Config Firewall
	* Turn Firewall on For Public, Private, Domain
	* Create Firewall Rules to Allow 5003 Load Balancer for IPs 10.243.46.3, 10.243.46.4, 10.243.46.5
* Start it all up

### Updating from zip file

* Backup current site as "production.zip"
* Current site is "production"
* Download Master.zip to desktop
* Unzip Master.zip to Master folder desktop
* NOTE: Preserve these files (keep them, do NOT overwrite)
	* web.config
	* production.sqlite
	* public\quaranta <- all files (NOTE this assumes the ones from production are more recent
	* copy vendor folder from old install into new folder
* copy web.config and production.sqlite files from production folder to same place in master folder
* Change Security on folder
	* C:\inetpub\wwwroot\app\storage\
		* Give IIS_IUSRS group MODIFY permission
		* change Advanced Permissions, Change Permission `Replace all child object permissions with inheritable permissions...`
		* apply inheritance DO NOT CLICK APPLY CLICK OK \ OK until back to users list level
	*  C:\inetpub\wwwroot\app\database
		* Give IIS_IUSRS group MODIFY permission
		* change Advanced Permissions, Change Permission `Replace all child object permissions with inheritable permissions...`
		* apply inheritance DO NOT CLICK APPLY CLICK OK \ OK until back to users list level

#### After downloading a new .zip from github my app errors in IIS with directory persmissions / security

if http://server/index.php works then add index.php as a default document

### Post Install Config Settings

>>>> Email SSL Certificate and Public Key to App Developer for use in the compiling the iPAD app <<<<

#### Dev mode settings
* FileMaker Database path fmp://quaranta.neocodesoftware.com/fmserver_sample
* Port Open Length (minutes) - 5 minutes
#### Prod mode settings
* FileMaker Database path fmp://quaranta.neocodesoftware.com/fmserver_sample
* Port Open Length (minutes) - 60 minutes

### Update web application

* cd \inetpub\wwwroot
* git pull
* php artisan migrate

### FORCE REINSTALL

To REPLACE ALL wwwwroot files you can force git to overwrite local files on pull with these commans

* git fetch --all
* git reset --hard origin/master
* php artisan migrate (in case of db migrations)
 
To if composer.json & app/config/app.php are modified then run

`composer update -d c:\inetpub\wwwroot\`

### Unit Tests

* `cd C:\inetpub\wwwroot`
* `php vendor/phpunit/phpunit/phpunit.php app/tests/ChallengeApiControllerTest.php`
* `php vendor/phpunit/phpunit/phpunit.php app/tests/QueuesTest.php`
## Logs

* Web service logs
	* `c:\inetpub\wwwroot\app\storage\logs\log-cli-[date].txt`
