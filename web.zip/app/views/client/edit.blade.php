@extends('layouts.main')

@section('content')

	@include('success')

	<h2>Quaranta Edit Client</h2>

	{{ Form::model($client, array('class'=>'form-horizontal', 'method' => 'PUT', 'action' => array('ClientController@update', $client->id))) }}
	<fieldset>
		<div class="form-group">
			{{ Form::label('first_name', 'First Name') }}
			{{ Form::text('first_name') }}
			<div class="text-error">{{{ $errors->first('first_name') }}}</div>
		</div>

		<div class="form-group">
			{{ Form::label('last_name', 'Last Name') }}
			{{ Form::text('last_name') }}
			<div class="text-error">{{{ $errors->first('last_name') }}}</div>
		</div>

		<div>
			{{ Form::label('email', 'Email Address') }}
			{{ Form::input('email','email') }}
			<div class="text-error">{{{ $errors->first('email') }}}</div>
		</div>

		<div>
			<br />
			{{ Form::submit('Save Changes', array('class' => 'btn btn-danger', 'onclick' => "return confirm('Save Changes?');")) }}
		</div>

	</fieldset>
	{{ Form::close() }}
@stop
