@extends('layouts.main')

@section('content')
	
	@include('success')

	<h2>Viewing Client</h2> 

	<dl>
		<dt>Name</dt>
		<dd>{{{ $client->full_name() }}}</dd>

		<dt>Email</dt>
		<dd>{{{ $client->email }}}</dd>

		<dt>Temporary Password</dt>
		<dd>{{{ $client->temp_pass }}}</dd>
	</dl>

	@unless ($client->deleted_at)
	{{ Form::open(array('method' => 'DELETE', 'action' => array('ClientController@destroy', $client->id))) }}
	{{ Form::submit('Disable Client (Permanently)', array('class' => 'btn btn-danger', 'onclick' => 'return confirm("Are you sure? This can\'t be undone.")')) }}
	{{ Form::close() }}
	@endunless

	<div class="device-list">
		<h3>Device List</h3>
		<table class="table table-bordered">
			<thead>
				<tr>
					<th>Device ID</th>
					<th>CSR</th>
					<th>Approved</th>
					<th>Created On</th>
					<th>Last Updated</th>
				</tr>
			</thead>
			@foreach ($client->devices as $device)
			<tr>
				<td><tt>{{{ $device->device_id }}}</tt></td>
				<td>
					@unless (empty($device->ssl_csr))
						<a href="{{ URL::action('DeviceController@show', array($device->id)) }}">View</a>
					@else
						Unavailable
					@endunless
				</td>
				<td>{{{ ($device->approved) ? "Yes" : "No" }}}</td>
				<td>{{{ $device->created_at }}}</td>
				<td>{{{ $device->updated_at }}}</td>
			</tr>
			@endforeach
		</table>
	</div>
@stop
