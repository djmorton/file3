@extends('layouts.main')

@section('content')
	@include('success')
	
	<h2>Quaranta Client User List</h2>

	<table class="table table-striped">
		<thead>
			<tr>
				<th>Name</th>
				<th>Email</th>
				<th>Active</th>
				<th>&nbsp;</th>
			</tr>
		</thead>

		@foreach ($clients as $client)
		<tr>
			<td>{{{ $client->first_name }}} {{{ $client->last_name }}}</td>
			<td>{{{ $client->email }}}</td>
			<td>{{{ $client->deleted_at ? "No" : "Yes" }}}</td>
			<td>
				@unless ($client->deleted_at)
				<a href="{{ URL::action('ClientController@show', array($client->id)) }}">View</a>
				| 
				<a href="mailto:{{{$client->email}}}?subject={{{$setting->email_subject}}}&amp;body={{ $setting->email_body_parsed($client) }}">Email</a>
				|
				<a href="{{ URL::action('ClientController@edit', array($client->id)) }}">Edit</a>
				@endunless
			</td>
		</tr>
		@endforeach

	</table>

	<a href="{{ URL::action('ClientController@create') }}" class="btn btn-primary">Add New Client</a>
	
	<div class="bulk_client_form">
	<h2>Bulk Client Import</h2>

	{{ Form::open(array('method' => 'POST', 'route' => array('client.batch'))) }}
	{{ Form::textarea('batch', '', array('style' => 'width:520px', 'placeholder' => "FirstName, LastName, Email")) }}
	@if($errors->any())
	<p class="errors text-error">
		{{{ $errors->first('batch') }}}
	</p>
	@endif
	<br />
	{{ Form::submit('Add New Clients', array('class' => 'btn btn-primary')) }}
	{{ Form::close() }}
	</div>

@stop
