@extends('layouts.main')

@section('content')

	<h2>Batch Report:</h2>

	<p>There were problems importing the batch with the following users/data:</p>
	
	<table class="table table-striped">
		<thead>
			<tr>
				<th>First Name</th>
				<th>Last Name</th>
				<th>Email</th>
				<th>Error</th>
			</tr>
		</thead>
	@foreach($fail_clients as $fClient)
		<tr>
			<td>{{{ $fClient['first_name'] }}}</td>
			<td>{{{ $fClient['last_name'] }}}</td>
			<td>{{{ $fClient['email'] }}}</td>
			<td>{{ $fClient['errors'] }}</td>
		</tr>
	@endforeach
	</table>

	@unless(empty($clients))
	<p>Successfully added clients:</p>

	<table class="table table-striped">
		<thead>
			<tr>
				<th>ID</th>
				<th>Name</th>
				<th>Email</th>
			</tr>
		</thead>

		@foreach ($clients as $client)
		<tr>
			<td>{{{ $client->id }}}</td>
			<td>{{{ $client->first_name }}} {{{ $client->last_name }}}</td>
			<td>{{{ $client->email }}}</td>
		</tr>
		@endforeach
	</table>
	@endunless

	<a href="/client" class="btn btn-primary">OK</a>
@stop