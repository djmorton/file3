@extends('layouts.main')

@section('content')
	
	@include('success')

	<h2>{{{ $logs->id }}}</h2>

	<pre class="logs pre-scrollable">
@foreach($logs->filter('log.INFO') as $id => $line)
{{{ $line }}}
@endforeach
	</pre>

@stop
