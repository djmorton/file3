@extends('layouts.main')

@section('content')
	
	@include('success')

	<h2>Log Files</h2> 

	<ul>
		@foreach($logs->file_list as $id => $log)
		<li>
			<a href="{{ URL::action('LogController@show', array('log' => $id)) }}">{{{ $log }}}</a>
		</li>
		@endforeach
	</ul>

@stop
