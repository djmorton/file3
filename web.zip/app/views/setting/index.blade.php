@extends('layouts.main')

@section('content')
	
	@include('success')

	{{ Form::model($setting, array('method' => 'PUT', 'action' => array('SettingController@update', $setting->id))) }}

	<a href="#password_settings">Password Settings</a> | <a href="#email_template_settings">Email Template Settings</a>


	<h2>Server Settings</h2>
	<dl>

		<dt>Allow NAT Connections</dt>
		<dd>{{ Form::text('debug_mode', $setting->debug_mode, array('pattern' => "(on|On|Off|off)")) }}</dd>
		<dd class="text-warning">{{ $errors->first('debug_mode') }}</dd>

		<dt>FileMaker Server URL</dt>
		<dd>{{ Form::text('fmp_redirect_url') }}</dd>
		<dd class="text-warning">{{ $errors->first('fmp_redirect_url') }}</dd>

		<dt>FileMaker Server Port</dt>
		<dd>{{ Form::text('fmp_server_port') }}</dd>
		<dd class="text-warning">{{ $errors->first('fmp_server_port') }}</dd>

		<dt>Web Server Server Port</dt>
		<dd>{{ Form::text('web_server_port') }}</dd>
		<dd class="text-warning">{{ $errors->first('web_server_port') }}</dd>

		<dt>Port Open Length (minutes)</dt>
		<dd>{{ Form::text('minutes_open') }}</dd>
		<dd class="text-warning">{{ $errors->first('minutes_open') }}</dd>

		<dt>IP Whitelist</dt>
		<dd>{{ Form::textarea('ip_white_list') }}</dd>
		<dd class="text-warning">{{ $errors->first('ip_white_list') }}</dd>

		<dt>SSL Certificate</dt>
		<dd>{{ Form::textarea('server_ssl_cert', $setting->server_ssl_cert, array('class' => 'wide')) }}</dd>
		<dd class="text-warning">{{ $errors->first('server_ssl_cert') }}</dd>

		<dt>SSL Public Key</dt>
		<dd>{{ Form::textarea('server_ssl_pubkey', $setting->server_ssl_pubkey, array('class' => 'wide')) }}</dd>
		<dd class="text-warning">{{ $errors->first('server_ssl_pubkey') }}</dd>


		<a id="password_settings"></a>
		<h3>Password/Login Hygiene Settings</h3>

		<dt>Account Expires After X Days</dt>
		<dd>{{ Form::input('number', 'account_disabled_after_x_days') }}</dd>
		<dd class="text-warning">{{ $errors->first('account_disabled_after_x_days') }}</dd>

		<dt>Account Expires After X Days Inactivity</dt>
		<dd>{{ Form::input('number', 'account_disabled_after_x_days_inactivity') }}</dd>
		<dd class="text-warning">{{ $errors->first('account_disabled_after_x_days_inactivity') }}</dd>

		<dt>Account Disabled After X Failed Login Attempts</dt>
		<dd>{{ Form::input('number', 'account_disabled_after_x_failed_attempts') }}</dd>
		<dd class="text-warning">{{ $errors->first('account_disabled_after_x_failed_attempts') }}</dd>

		<dt>Validate password isn't email address</dt>
		<dd>{{ Form::text('validate_password_not_account_name', $setting->validate_password_not_account_name, array('pattern' => "(on|On|Off|off)")) }}</dd>
		<dd class="text-warning">{{ $errors->first('validate_password_not_account_name') }}</dd>

		<dt>Validate password contains at least one letter</dt>
		<dd>{{ Form::text('validate_password_contains_one_letter', $setting->validate_password_contains_one_letter, array('pattern' => "(on|On|Off|off)")) }}</dd>
		<dd class="text-warning">{{ $errors->first('validate_password_contains_one_letter') }}</dd>

		<dt>Validate password contains at least one number</dt>
		<dd>{{ Form::text('validate_password_contains_one_number', $setting->validate_password_contains_one_number, array('pattern' => "(on|On|Off|off)")) }}</dd>
		<dd class="text-warning">{{ $errors->first('validate_password_contains_one_number') }}</dd>

		<dt>Password requires reset on first login</dt>
		<dd>{{ Form::text('validate_password_reset_on_first_login', $setting->validate_password_reset_on_first_login, array('pattern' => "(on|On|Off|off)")) }}</dd>
		<dd class="text-warning">{{ $errors->first('validate_password_reset_on_first_login') }}</dd>

		<dt>Validate passwords contain at least X characters</dt>
		<dd>{{ Form::input('number', 'validate_password_contains_x_characters') }}</dd>
		<dd class="text-warning">{{ $errors->first('validate_password_contains_x_characters') }}</dd>

		<dt>Validate passwords differ from last X user passwords</dt>
		<dd>{{ Form::input('number', 'validate_password_differs_from_last_x') }}</dd>
		<dd class="text-warning">{{ $errors->first('validate_password_differs_from_last_x') }}</dd>

		<dt>Passwords reset every X days</dt>
		<dd>{{ Form::input('number', 'pasword_resets_every_x_days') }}</dd>
		<dd class="text-warning">{{ $errors->first('pasword_resets_every_x_days') }}</dd>


		<a id="email_template_settings"></a>
		<h3>Email Template Settings</h3>

		<span class="help-block" style="width:514px">Available email body placeholder values:
<pre>
User:
	USER_FIRST_NAME
	USER_LAST_NAME
 	USER_TEMP_PASS

Global:
	QUARANTA_EMAIL
	APP_DOWNLOAD_URL
</pre></span>

		<dt>Email Subject (Invited to Register)</dt>
		<dd>{{ Form::text('email_subject', $setting->email_subject, array('style' => "width:500px")) }}</dd>
		<dd class="text-warning">{{ $errors->first('email_subject') }}</dd>

		<dt>Email Body Template (Invited to Register)</dt>
		<dd>{{ Form::textarea('email_body', $setting->email_body, array('class' => "wide")) }}</dd>
		<dd class="text-warning">{{ $errors->first('email_body') }}</dd>

		<dt>Email Subject (Device Approved)</dt>
		<dd>{{ Form::text('email_subject_device_approved', $setting->email_subject_device_approved, array('style' => "width:500px")) }}</dd>
		<dd class="text-warning">{{ $errors->first('email_subject_device_approved') }}</dd>

		<dt>Email Body (Device Approved)</dt>
		<dd>{{ Form::textarea('email_body_device_approved', $setting->email_body_device_approved, array('class' => "wide")) }}</dd>
		<dd class="text-warning">{{ $errors->first('email_body_device_approved') }}</dd>


	</dl>


	{{ Form::submit('Save Settings', array('class' => 'btn btn-danger', 'onclick' => "return confirm('You want to overwrite the old settings with these new settings?');")) }}
	{{ Form::close() }}

@stop
