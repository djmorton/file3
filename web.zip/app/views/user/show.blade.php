@extends('layouts.main')

@section('content')

	@include('success')

	<h2>Quaranta Admin User</h2>
	<dl>
		<dt>Name</dt>
		<dd>{{{ $user->first_name . " " . $user->last_name }}}</dd>

		<dt>Email</dt>
		<dd>{{{ $user->email }}}</dd>

		<dt>Active</dt>
		<dd>{{{ $user->deleted_at ? "No" : "Yes" }}}</dd>
	</dl>

	@unless ($user->deleted_at)
	{{ Form::open(array('method' => 'DELETE', 'action' => array('UserController@destroy', $user->id))) }}
	{{ Form::submit('Suspend Admin', array('class' => 'btn btn-danger', 'onclick' => 'return confirm("Are you sure?")')) }}
	{{ Form::close() }}
	@endunless

@stop
