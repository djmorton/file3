@extends('layouts.main')

@section('content')
	<h2>Add new Admin User</h2>

	{{ Form::model($user, array('action' => 'UserController@store')) }}

	<!-- email field -->
	<p>{{ Form::label('email', 'Email') }}</p>
	<p>{{ Form::text('email') }} {{ $errors->first('email') }}</p>


	<p>{{ Form::label('first_name', 'First Name') }}</p>
	<p>{{ Form::text('first_name') }} {{ $errors->first('first_name') }}</p>

	<p>{{ Form::label('last_name', 'Last Name') }}</p>
	<p>{{ Form::text('last_name') }} {{ $errors->first('last_name') }}</p>

	<!-- submit button -->
	<p>{{ Form::submit('Create', array('class' => 'btn btn-primary')) }}</p>
	{{ Form::close() }}
@stop