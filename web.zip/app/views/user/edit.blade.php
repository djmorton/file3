@extends('layouts.main')

@section('content')

	@include('success')

	@if (Session::has('password_requires_reset'))
	<div class="errors text-error">
		<p>You are required to choose a new password every {{ Setting::get('pasword_resets_every_x_days') }} days.</p>
		<p>It has been {{ Session::get('password_requires_reset') }} Since you last updated your password.</p>
	</div>
	@endif

	<h2>Quaranta Edit Admin User</h2>

	{{ Form::model($user, array('class'=>'form-horizontal', 'method' => 'PUT', 'action' => array('UserController@update', $user->id))) }}
	<fieldset>
		<div class="form-group">
			{{ Form::label('first_name', 'First Name') }}
			{{ Form::text('first_name') }}
			<div class="text-error">{{{ $errors->first('first_name') }}}</div>
		</div>

		<div class="form-group">
			{{ Form::label('last_name', 'Last Name') }}
			{{ Form::text('last_name') }}
			<div class="text-error">{{{ $errors->first('last_name') }}}</div>
		</div>

		<div>
			{{ Form::label('email', 'Email Address (login)') }}
			{{ Form::input('email','email') }}
			<div class="text-error">{{{ $errors->first('email') }}}</div>
		</div>
		
		<h4>Change Password</h4>
		<div class="form-group">
			{{ Form::label('current_password', 'Current Password') }}
			{{ Form::password('current_password') }}
			<div class="text-error">{{ implode($errors->get('current_password', '<p>:message</p>')) }}</div>
		</div>


		<div class="form-group">
			{{ Form::label('new_password', 'New Password') }}
			{{ Form::password('new_password') }}
			<div class="text-error">{{ implode($errors->get('new_password', '<p>:message</p>')) }}</div>
		</div>

		<div class="form-group">
			{{ Form::label('new_password_confirmation', 'Verify Password') }}
			{{ Form::password('new_password_confirmation') }}
			<div class="text-error">{{ implode($errors->get('new_password_confirmation', '<p>:message</p>')) }}</div>
		</div>

		<div>
			<br />
			{{ Form::submit('Save Changes', array('class' => 'btn btn-danger', 'onclick' => "return confirm('Save Changes?');")) }}
		</div>

	</fieldset>
	{{ Form::close() }}
@stop
