
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <title>Quaranta</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">

    <!-- Le styles -->
    @section('css')
      <link href="/css/bootstrap.min.css" rel="stylesheet">
      <link href="/css/main.css" rel="stylesheet">
    @show
    
    <style type="text/css">
      body {
        padding-top: 60px;
        padding-bottom: 40px;
      }
      .sidebar-nav {
        padding: 9px 0;
      }

      @media (max-width: 980px) {
        /* Enable use of floated navbar text */
        .navbar-text.pull-right {
          float: none;
          padding-left: 5px;
          padding-right: 5px;
        }
      }
    </style>
    
    @section('js')
      <script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
    @show

  </head>

  <body>

    <div class="navbar navbar-inverse navbar-fixed-top">
      <div class="navbar-inner">
        <div class="container-fluid">
          <button type="button" class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="brand" href="#">Quaranta</a>
          <div class="nav-collapse collapse">
            <p class="navbar-text pull-right">
            	@if( Auth::check() )
              	Logged in as <a href="/user/{{ Auth::user()->id }}" class="navbar-link">{{ Auth::user()->email }}</a> 
              	| 
              	<a href="/logout">Logout</a>
              @else
              	<a href="/login">Login</a>
              @endif
            </p>
            <ul class="nav">
              <li class="active"><a href="#">Home</a></li>
              <li><a href="#about">About</a></li>
              <li><a href="#contact">Contact</a></li>
            </ul>
          </div><!--/.nav-collapse -->
        </div>
      </div>
    </div>

    <div class="container-fluid">
      <div class="row-fluid">
        <div class="span3">
          <div class="well sidebar-nav">
            <ul class="nav nav-list">
              <li class="nav-header">Quaranta Menu</li>
              <li><a href="/">Home</a></li>
              <li class=""><a href="{{ URL::action('UserController@index') }}">Admin Users</a></li>
              <li><a href="{{ URL::action('ClientController@index') }}">Client Users</a></li>
              <li><a href="{{ URL::action('LogController@index') }}">Logs</a></li>
              <li><a href="{{ URL::action('SettingController@index') }}">Settings</a></li>

          </div><!--/.well -->
        </div><!--/span-->
        <div class="span9">
          <div class="hero-unit">
          	@yield('content')
          </div>
          <div class="row-fluid">

          </div><!--/row-->

        </div><!--/span-->
      </div><!--/row-->

      <hr>

      <footer>
        <p>&copy; NeoCode Software 2013</p>
      </footer>

    </div><!--/.fluid-container-->

  </body>
</html>
