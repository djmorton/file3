@extends('layouts.main')

@section('content')
	@include('success')

	<h2>Device CSR</h2>
	for <a href="{{ URL::action('ClientController@show', array($device->client->id)) }}">{{{ $device->client->full_name() }}}</a>
	<dl>
		<dt>ID</dt>
		<dd>{{{ $device->device_id }}}</dd>

		<dt>CSR Organization [O]</dt>
		<dd>{{{ $device->csr()->O }}}</dd>

		<dt>CSR Common Name [CN]</dt>
		<dd>{{{ $device->csr()->CN }}}</dd>

		<dt>CSR Location [L] [ST] [C]</dt>
		<dd>{{{ $device->csr()->L }}}, {{{ $device->csr()->ST }}} {{{ $device->csr()->C }}}</dd>

		<dt>CSR Device ID [OU]</dt>
		<dd>{{{ $device->csr()->OU }}}</dd>

		<dt>CSR Email Address</dt>
		<dd>{{{ $device->csr()->emailAddress }}}</dd>

		<dt>Approved</dt>
		<dd>{{{ ($device->approved) ? "Yes" : "No" }}}</dd>

		<dt>Created On</dt>
		<dd>{{{ $device->created_at }}}</dd>

		<dt>Last Updated On</dt>
		<dd>{{{ ($device->updated_at) }}}</dd>

		@if($device->approved)
		<dt>Certificate</dt>
		<dd><pre>{{{ $device->ssl_cert }}}</pre></dd>

		<dt>Certificate Expires</dt>
		<dd>{{{ $device->ssl_cert_expires }}}</dd>
		@endif

	</dl>

	@unless($device->approved)
		{{ Form::open(array('method' => 'PUT', 'action' => array('DeviceController@update', $device->id))) }}
		{{ Form::hidden('approved', 'true') }}
		@if($device->client->hasApprovedDevice())
			{{ Form::submit('Approve Device CSR', array('class' => 'btn', 'disabled' => 'disabled')) }}
			<span class="help-block">This device can't be approved because another device is already approved.</span>
		@else
			{{ Form::submit('Approve Device CSR', array('class' => 'btn btn-success')) }}
		@endif
		{{ Form::close() }}
	@endif

	@if($device->approved)
		{{ Form::open(array('method' => 'PUT', 'action' => array('DeviceController@update', $device->id))) }}
		{{ Form::hidden('approved', 'false') }}
		{{ Form::submit('Revoke Device', array('class' => 'btn btn-danger', 'onclick' => "return confirm('Are you sure?')")) }}
		{{ Form::close() }}
	@endif

@stop
