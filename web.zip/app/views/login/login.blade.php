@extends('layouts.main')

@section('content')
	{{ Form::open( array('url' => 'login') ) }}

	@if (Session::has('account_disabled_for_inactivity'))
	<div class="errors text-error">
		<p>This account has been disable for inactivity.</p>
		<p>The max number of days of inactivity allowed are {{ Setting::get('account_disabled_after_x_days_inactivity') }} 
		and this account has been inactive for  {{ Session::get('account_disabled_for_inactivity') }} days.</p>
	</div>
	@endif

	@if (Session::has('account_expired'))
	<div class="errors text-error">
		<p>This account has expired.</p>
		<p>Accounts are only active for {{ Setting::get('account_disabled_after_x_days') }} days, this account is {{ Session::get('account_expired') }} days old.</p>
	</div>
	@endif

	@if (Session::has('locked_failed_attempts'))
	<div class="errors text-error">
		<p>This account has disabled for too many failed login attempts.</p>
		<p>Accounts are disabled after {{ Setting::get('account_disabled_after_x_failed_attempts') }} failed login attempts, 
		this account has {{ Session::get('locked_failed_attempts') }} failed login attempts.</p>
	</div>
	@endif

	<!-- check for login errors flash var -->
	@if (Session::has('login_errors'))
	<span class="text-error">Email or password incorrect.</span>
	@endif
	<!-- email field -->
	<p>{{ Form::label('email', 'Email') }}</p>
	<p>{{ Form::text('email') }}</p>
	<!-- password field -->
	<p>{{ Form::label('password', 'Password') }}</p>
	<p>{{ Form::password('password') }}</p>
	<!-- submit button -->
	<p>{{ Form::submit('Login') }}</p>
	{{ Form::close() }}
@stop
