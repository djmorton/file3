<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateSettingsTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('settings', function(Blueprint $table)
		{
			$table->increments('id');
			
			$table->string('fmp_redirect_url');
			$table->integer('web_server_port');
			$table->integer('fmp_server_port');
			$table->integer('minutes_open');

			$table->text('ip_white_list');

			$table->string('email_subject');
			$table->text('email_body');

			$table->text('email_body_device_approved');
			$table->string('email_subject_device_approved');

			$table->text('server_ssl_privkey');
			$table->text('server_ssl_pubkey');
			$table->text('server_ssl_cert');

			// * ON / OFF On specific date [Date] – default OFF
			$table->date('logins_disabled_after')->nullable();
			
			// * ON / OFF After using it for [X] days – default OFF
			$table->integer('account_disabled_after_x_days')->default(0);

			// * ON / OFF After inactive for [X] days – default OFF
			$table->integer('account_disabled_after_x_days_inactivity')->default(0);

			// * ON / OFF After user makes [X] failed attempts – default ON – 5 attempts
			$table->integer('account_disabled_after_x_failed_attempts')->default(5);

			// * ON / OFF Differ from account name – default ON
			$table->boolean('validate_password_not_account_name')->default(1);

			// * ON / OFF Contain at least one letter – default ON
			$table->boolean('validate_password_contains_one_letter')->default(1);

			// * ON / OFF Contain at least one numeric character – default ON
			$table->boolean('validate_password_contains_one_number')->default(1);

			// * ON / OFF Be reset on first login – default ON
			$table->boolean('validate_password_reset_on_first_login')->default(1);

			// * ON / OFF Contain at least [X] characters – default ON – 8 characters
			$table->integer('validate_password_contains_x_characters')->default(8);

			// * ON / OFF Differ from last [X] passwords used – default ON – 25 passwords
			$table->integer('validate_password_differs_from_last_x')->default(25);

			// * ON / OFF Be reset every [X] [days / months] – default ON – 42 days
			$table->integer('pasword_resets_every_x_days')->default(42);
			
			$table->timestamps();
		});
	}

	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('settings');
	}

}
