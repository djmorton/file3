<?php

use Illuminate\Database\Migrations\Migration;

class AddFailedLoginCountColumnToClients extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::table('clients', function($table)
		{
			$table->integer('failed_login_count')->default(0);
		});
	}

	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::table('clients', function($table)
		{
			$table->dropColumn('failed_login_count');
		});
	}

}