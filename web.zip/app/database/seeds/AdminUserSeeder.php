<?php

class AdminUserSeeder extends Seeder {
	
	public function run()
	{
		// DB::table('users')->delete();

		User::create(array(
			'email' => 'admin@quaranta.com',
			'first_name' => 'Admin',
			'last_name' => 'User',
			'password' => Hash::make('admin@quaranta.com'),
			'password_updated_at' => new DateTime()
		));

	}

}
