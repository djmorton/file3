<?php

/**
* 
*/
class SettingsSeeder extends Seeder
{
	
	public function run()
	{
		// Build server SSL key & cert
		Setting::create(array(
			'server_ssl_privkey' => '-----BEGIN RSA PRIVATE KEY-----
MIICWwIBAAKBgQC1/RlktOm73Y0gALo5L0WKbANL7waRBU4T2gkg/gO8IhzRB8QD
BgwKlOFnnSsX/g2f9558uyV+LJ1WR7uNTpKeDEmQ0qFrCWRS8zJC3g2NN//aVoCG
6kprnvorR4j8N98WSG8UNDQ7Fzz6HcKDBtkLfgnnZizjNpTyIDccrE/t7QIDAQAB
AoGAUhWu9nWDV3E+zkiFtnVT8HN3qTBOzeqOpPWbWH46QQlB5iaSiqqXk85DPPDv
FwtIKfcOTUQ8TQTikqAYQExIZKzOfl3KPpfNhoMrYQDAH1Pw9CQs2UgJWKt89sNd
6ionNC6H/QpJ+FCm9C0WwQevg/SHqlyhsaSd8/bDHCyqcCECQQD2OoX9kSEKZfNR
Se+nZ0vGeJWZMjf7Sp2V+GDKDKcqr9THRQFxeRzioEfn7HsqYeUa5RRDpBMpAQPm
VRQSpV1bAkEAvTXzp5vbIDa3D7RTqaYviIchFWzQlrXN/knlF4e3S0AJZ7ORmQf/
1kFW7gifmqRcL1u00jNVKPK0VYjpFBncVwJASUdBeSUn4CBXOWn3mKp1MqvQWbdI
UdDy9R7mLzt0xI9vk55Fv697mTZ6L9uBDCv2MvrZ/QdnbFyQ/It1Xdc44QJAdtCk
WsISTh5NwjzYtJW5D6Dbc5rLOXidDGvWwnnk7goeXdJzQYe2bhLFxeAAaZmAkfSi
jcTSW05dU8EPrCG5LQJAXvACNRATHt/Ug7gh9EjHUUbNwVKWiM1x2hTy9xknkHqG
RJWtowaH1b7OjoK7HHWrDuAITmmOcdW5xeKkNM8pRA==
-----END RSA PRIVATE KEY-----',
			'server_ssl_pubkey' => '-----BEGIN PUBLIC KEY-----
MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQC1/RlktOm73Y0gALo5L0WKbANL
7waRBU4T2gkg/gO8IhzRB8QDBgwKlOFnnSsX/g2f9558uyV+LJ1WR7uNTpKeDEmQ
0qFrCWRS8zJC3g2NN//aVoCG6kprnvorR4j8N98WSG8UNDQ7Fzz6HcKDBtkLfgnn
ZizjNpTyIDccrE/t7QIDAQAB
-----END PUBLIC KEY-----',
			'server_ssl_cert' => '-----BEGIN CERTIFICATE-----
MIIBrDCCARegAwIBAgIBADALBgkqhkiG9w0BAQUwHTEbMBkGA1UECgwScXVhcmFu
dGEgZGVtbyBjZXJ0MCIYDzIwMTMwOTE2MTUzNzM5WhgPMjAxNDA5MTYxNTM3Mzla
MB0xGzAZBgNVBAoMEnF1YXJhbnRhIGRlbW8gY2VydDCBnTALBgkqhkiG9w0BAQED
gY0AMIGJAoGBALX9GWS06bvdjSAAujkvRYpsA0vvBpEFThPaCSD+A7wiHNEHxAMG
DAqU4WedKxf+DZ/3nny7JX4snVZHu41Okp4MSZDSoWsJZFLzMkLeDY03/9pWgIbq
Smue+itHiPw33xZIbxQ0NDsXPPodwoMG2Qt+CedmLOM2lPIgNxysT+3tAgMBAAEw
CwYJKoZIhvcNAQEFA4GBAJQQMGI1PJs7lCaTm3N9pmbN253T4lzrGOzrZW2q0Kjs
GVTsFqaOckk0DtDU60N7YTx/y+bD7NpqXQw4SBKHV4ZNv3CrJ1yKiB8AN3oADrPZ
j8fjS89laBvpXDjZbFLl1RqMqkdLoaLa9EIe5weR8/B7CKAs1DR9urwdea1yXcRu
-----END CERTIFICATE-----',
			'fmp_redirect_url' => 'fmp://quaranta.dev/',
			'fmp_server_port' => 5003,
			'web_server_port' => 443,
			'minutes_open' => 1,
			'ip_white_list' => "154.5.170.126\n124.14.107.128",
			'email_subject' => "Quaranta Device Registration",
			'email_body' => 
			"
Hi USER_FIRST_NAME USER_LAST_NAME,

You have been invited to register your tablet device with Quaranta.

There are just 3 steps to completing this process:

1) Download the Quaranta app from APP_DOWNLOAD_URL to get started.

2) Enter your assigned temporary password as shown here:
                USER_TEMP_PASS

3) Wait for a Quaranta admin to contact you and verify your identity.

If you have any concerns, or you believe you are receiving this email in error, please contact us at QUARANTA_EMAIL.

Regards,
Quaranta Admin

",
			"email_subject_device_approved" => "Quaranta Device Successfully Registered",
			"email_body_device_approved" => "
Hi USER_FIRST_NAME USER_LAST_NAME,

The device you wished to register has been approved.

Please re-launch your app.

Regards,
Quaranta Admin

			"
		));
	}
}