<?php

/**
* 
*/
class TestDataSeeder extends Seeder
{
	
	public function run()
	{
		$client = Client::create(array(
			'email' => 'client@quaranta.com',
			'first_name' => 'Client',
			'last_name' => 'User'
		));

		$device = new Device(array(
			'client_id' => $client->id,
			'device_id' => '21xb1fxef5x2052xec31x3xd3x48ex5e437xe593',
			'ssl_csr' => "-----BEGIN CERTIFICATE REQUEST-----
MIIDNTCCAh0CAQAwgdgxCzAJBgNVBAYTAkNBMRkwFwYDVQQIExBCcml0aXNoIENv
bHVtYmlhMRIwEAYDVQQHEwlWYW5jb3V2ZXIxGTAXBgNVBAoTEE5lb0NvZGUgU29m
dHdhcmUxMTAvBgNVBAsTKDJiNmYwY2M5MDRkMTM3YmUyZTE3MzAyMzVmNTY2NDA5
NGI4MzExODYxIjAgBgNVBAMUGWNsaWVudF9hbHBoYUBxdWFyYW50YS5jb20xKDAm
BgkqhkiG9w0BCQEWGWNsaWVudF9hbHBoYUBxdWFyYW50YS5jb20wggEiMA0GCSqG
SIb3DQEBAQUAA4IBDwAwggEKAoIBAQDdJbRjwRpIXzApugZplnGkREyZZyQRNG7O
isV2/buTEJtABTu+YFFaba2F5hxvNp8Uztbf3g1123r24/PxgIdfrYYNeDTfObr7
aV0LDpXIpgxQTiTcnmJrvxeMBJl5Ov7QizspeQzKt2hDo8RNHoHwJQ+X5DX5a3YQ
QnDhgPKZFuyUP7cl/9bQvYd/r4BenMADSYp/D0S88EQ130Mihsd0hdQ76HKhe/TV
X3lUzbL1r0kKq4jFXvs/Ddx2hEaiKzlMrYQTKs9YhLXW/qOXWLfEsph+H0hrJ7O+
o6NJRcApoK2eMEb9oq3Dvz+tMbuOSYZS4fRhwJVVNDju+orz6PutAgMBAAGgFzAV
BgkqhkiG9w0BCQcxCBMGYWJjMTIzMA0GCSqGSIb3DQEBBQUAA4IBAQC7rV4+RMFA
YLitLlaw0U2hpAtmy1085WKEX+Y1e499sbbMgjEvUmR2/0C0kmauqtMteU7mDzKr
zSQXtLaaXIUE0k/jDo8n9knxfv5lk7hf1aQScsqr+vqXWFRjHtIy8xbXFV2pVqjD
dFd8uHT+B3P259PSbFbQ/YZMelR25neYivTFLCniTb05DZIBx41Lbv9pDN8xdlCb
jPTyLrqUN/+7nrOpE4SD1dE3DSbWnCDSVRJlDgDAUK3fZzFqGLUIlPchKuEPD2ZS
x4+YelbYeodQMJIBYaHQbseKdPsDCcHsqZBRZVjGHEPMsK6Qtj3pn/Wl1T7mTMCD
LXgBVnZ0B7HL
-----END CERTIFICATE REQUEST-----"
		));
		$client->devices()->save($device);


	}
}