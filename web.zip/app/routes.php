<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the Closure to execute when that URI is requested.
|
*/

// homepage route
Route::get('/', function()
{
	return View::make('hello');
});


// Resource routes, require login
Route::group(array('before' => 'auth'), function()
{
	// route to handle posting a bulk batch of
	// client email addresses to be created as 
	// users.
	Route::post('client/batch', array('as' => 'client.batch', 'uses' => 'ClientController@batch'));
	Route::get('client/report', array('as' => 'client.report', 'uses' => 'ClientController@report'));
	
	Route::resource('user', 	'UserController');
	Route::resource('client', 	'ClientController');

	Route::resource('device', 	'DeviceController');
	Route::resource('setting', 	'SettingController', array('only' => array('update', 'index')));

	Route::resource('log', 	'LogController', array('only' => array('show', 'index')));
});


// Login/Logout Routes
Route::get('login', 	array('uses' => 'LoginController@show'));
Route::post('login', 	array('uses' => 'LoginController@login'));
Route::get('logout', 	array('uses' => 'LoginController@logout'));


// API routes v1.0
Route::group(array('prefix' => 'api'), function()
{
	Route::get('/', 		array('uses' => 'ApiController@index'));
	Route::get('/rules', 	array('uses' => 'ApiController@rules'));
	Route::get('/validate', array('uses' => 'ApiController@validate'));
	Route::post('/log',  	array('uses' => 'ApiController@log'));

	Route::resource('device', 'DeviceApiController',  array('only' => array('store', 'update', 'show')));
	Route::resource('challenge', 'ChallengeApiController', array('only' => array('store', 'update')));
});
