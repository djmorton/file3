<?php

/*
** All Quaranta logging is done here via laravel event listeners
*/


Event::listen('auth.login', function($user)
{
	Log::info("Admin Login", array(
		'admin_id' 	=> $user->id,
		'admin_email' => $user->email
	));
});

Event::listen('auth.logout', function($user)
{
	Log::info("Admin Logout", array(
		'admin_id' 	=> $user->id,
		'admin_email' => $user->email
	));
});


class LogModelObserver {

	protected function stringify(Array $values)
	{
		foreach($values as $k => $v)
		{
			if( gettype($v) == "object" && get_class($v) == "DateTime" )
			{
				$values[$k] = $v->format('r');
			}
		}
		return json_encode($values);
	}

	public function created($model)
	{
		Log::info(get_class($model) . " Created", array(
			get_class($model) => $model->toJson(),
			'Created By' => (Auth::user() ? Auth::user()->toJson() : "null")
		));
	}

	public function deleting($model)
	{
		Log::info(get_class($model) . " Deleted", array(
			get_class($model) => json_encode($model->toArray()),
			'Deleted By' => (Auth::user() ? Auth::user()->toJson() : "null")
		));
	}

	public function updating($model)
	{
		Log::info(get_class($model) . " Updated", array(
			"New Values for " . get_class($model) . ": " => $this->stringify($model->getDirty()),
			'Updated By' => (Auth::user() ? Auth::user()->toJson() : "null")
		));
	}
}

Client::observe(new LogModelObserver);
User::observe(new LogModelObserver);
Device::observe(new LogModelObserver);
Challenge::observe(new LogModelObserver);
Setting::observe(new LogModelObserver);
