<?php

class DeviceApiControllerTest extends TestCase {
	
	/*
	** Setup
	*/
	protected $app_client;

	public function setUp()
	{
		
		parent::setUp();
		$this->seed();

		// sample client
		$this->app_client = Client::create(array(
			'email' => 'client_alpha@quaranta.com',
			'first_name' => 'Client',
			'last_name' => 'Alpha',
		));

		$this->privKey = new Crypt_RSA();
		$this->privKey->loadKey('-----BEGIN RSA PRIVATE KEY-----
MIICXgIBAAKBgQDOY4XYPdDdjiw6vgLGL5P9WY6c6qFUmF/WJdb7VSlWBmCqfgft
OwCdS1bMvK8MpUWFl5P0RvOQe7e6CwALufBwdtdNxzD2fPiJLKd9qCXrNCmk0Gc7
mOtnMaQagoguiMTDkZKp5QTYBZmJw2wVdD4VqOQAD1PhGOaTzZLsSdZXfQIDAQAB
AoGAG2rbiNQBb1qn49qCdNXfjjGmVpB8LnLwPFBvju42cmVLfyqvSTkO26vP/p0h
kLJTRNbTmAkQPy/oQttGPh3ijlkKxfVWOrSHLHp1y4dc+m/Juiz4t8ESGBPl1Y+K
9ETOzVBuXnAsx9bXTLUNCYA2M0T7NcgLFSI2YIJmFOFiffMCQQDbc3Zt83dOjj2G
JlE9l/kpnA51BjQoubv+8jRJxfCi5fdn1W4e/NSRFFyhTZvT5Q1PC8PkuRybFZ20
B2JPbgY3AkEA8MMi1111THrcHYubhWuNlTl6G66stlA5s7bjtNNSToTFr+0HhAML
Mdsz1kSbMuxLqERVLqHPQnBF4rK92Tz16wJBANhFGyLSvPKLFbD+VDQacLCEHm9P
9Nlp6g8gDU3jJ/qyHjeTTFp3mtl7sqo4/Og/pPUQyDbCA6IHFItWd5mF+dMCQQCg
f+V1Hsd4cZrVU2Ec42MiLIvbcmmOrBKbXHuV6x4+W8KRkfjlp0XKOa/n0hqIKwAQ
r2T9zj6lssTT6IYpELt7AkEAqC/TxX7Awdqpgr3WSTkfY3e8Z3lICjIoZt72eOXs
VbtHTYfZD/JYMIQ3X1HYf7W+POm/pbyKKGda5MJXPWNHMA==
-----END RSA PRIVATE KEY-----');

		// sample device
		$device = new Device(array(
			'device_id' => '2b6f0cc904d137be2e1730235f5664094b831186'
		));
		$this->app_client->devices()->save($device);

		// workaround to bug with model events not firing in tests
		$device->approved = false;
	}

	/*
	** Custom Assertions
	*/

	public function assertJsonErrorEquals($want, $response)
	{
		$json = json_decode($response->getContent());
		return $this->assertEquals($want, $json->error);
	}


	/*
	** Device STORE Action
	*/

	public function testDeviceStoreEmailNotFoundError()
	{
		$response = $this->action('POST', 'DeviceApiController@store', 
			array(
				'email' => 'foo@quaranta.com',
				'password' => 'wrongpassword',
			)
		);
		$this->assertJsonErrorEquals('client not found by email', $response);
	}

	public function testDeviceStorePasswordMismatchError()
	{
		$response = $this->action('POST', 'DeviceApiController@store', 
			array(
				'email' => $this->app_client->email,
				'password' => 'wrongpassword',
			)
		);
		$this->assertJsonErrorEquals('password mismatch', $response);
	}

	public function testDeviceStoreMissingDeviceIdError()
	{
		$x509 = new File_X509();
		$x509->setPrivateKey($this->privKey);
		$x509->setDNProp('id-at-organizationName', 'phpseclib demo cert');

		$csr = $x509->signCSR();

		$csr_pem = $x509->saveCSR($csr);

		$response = $this->action('POST', 'DeviceApiController@store', 
			array(
				'email' => $this->app_client->email,
				'password' => $this->app_client->temp_pass,
				'ssl_csr' => $csr_pem
			)
		);
		$this->assertJsonErrorEquals('device ID required', $response);
	}

	public function testDeviceStoreSuccess()
	{
		$x509 = new File_X509();
		$x509->setPrivateKey($this->privKey);
		$x509->setDNProp('id-at-organizationName', 'phpseclib demo cert');
		$x509->setDNProp('OU', '2b6f0cc904d137be2e1730235f5664094b831186');

		$csr = $x509->signCSR();

		$csr_pem = $x509->saveCSR($csr);
		
		$response = $this->action('POST', 'DeviceApiController@store', 
			array(
				'email' => $this->app_client->email,
				'password' => $this->app_client->temp_pass,
				'ssl_csr' => $csr_pem
			)
		);
		// check error is false
		$this->assertJsonErrorEquals(false, $response);

		// check other fields are include
		$json = json_decode($response->getContent());

		// device record id returned
		$this->assertNotEmpty($json->device_record_id);

		// client id returned
		$this->assertEquals($json->client_id, $this->app_client->id);
		
		// did we actually save the csr?
		$device = Device::find($json->device_record_id);
		$this->assertEquals($device->ssl_csr, $csr_pem);
	}


	/*
	** Device Show Action
	*/

	public function testDeviceShowMissingDeviceIdError()
	{
		$response = $this->action('GET', 'DeviceApiController@show', 
			array(
				'device' => 'wrong_device_id',
				'password' => $this->app_client->temp_pass
			)
		);
		$this->assertJsonErrorEquals('device not found', $response);
	}

	public function testDeviceShowSuccess()
	{
		$response = $this->action('GET', 'DeviceApiController@show', 
			array(
				'password' 	=> $this->app_client->temp_pass,
				'device' 	=> $this->app_client->devices[0]->id
			)
		);
		// check error is false
		$this->assertJsonErrorEquals(false, $response);

		$json = json_decode($response->getContent());

		// approved or not returned

		// ssl_cert returned

		// ssl_expiration date returned
	}


	public function testClientDeletedRelatedDeviceShowRaiseException()
	{
		// if the client was deleted, then so should the
		// related devices.
		$this->app_client->delete();
		
		// normally triggered as an event, but events don't work in tests
		$this->app_client->cascade_delete();

		$response = $this->action('GET', 'DeviceApiController@show', 
			array(
				'password' 	=> $this->app_client->temp_pass,
				'device' 	=> $this->app_client->devices[0]->id
			)
		);

		$this->assertJsonErrorEquals('device not found', $response);
	}

	public function testClientDeletedRelatedDeviceStoreRaiseException()
	{
		// if the client was deleted, then so should the
		// related devices.
		$this->app_client->delete();

		// normally triggered as an event, but events don't work in tests
		$this->app_client->cascade_delete(); 

		// generate CSR to submit
		$x509 = new File_X509();
		$x509->setPrivateKey($this->privKey);
		$x509->setDNProp('id-at-organizationName', 'phpseclib demo cert');
		$x509->setDNProp('OU', '2b6f0cc904d137be2e1730235f5664094b831186');

		$csr = $x509->signCSR();
		$csr_pem = $x509->saveCSR($csr);

		$response = $this->action('POST', 'DeviceApiController@store', 
			array(
				'email' => $this->app_client->email,
				'password' => $this->app_client->temp_pass,
				'ssl_csr' => $csr_pem
			)
		);

		$this->assertJsonErrorEquals('client not found by email', $response);
	}

	public function testApiControllerValidateAction()
	{
		$response = $this->action('GET', 'ApiController@validate', 
			array(
				'email' => $this->app_client->email,
				'password' => $this->app_client->temp_pass
			)
		);

		$this->assertJsonErrorEquals(false, $response);

		$client = Client::find($this->app_client->id);
		$this->assertNotEquals($client->temp_pass, $this->app_client->temp_pass);
	}

	public function testApiControllerValidateActionError()
	{
		$response = $this->action('GET', 'ApiController@validate', 
			array(
				'email' => $this->app_client->email,
				'password' => 'wrong'
			)
		);

		$this->assertJsonErrorEquals('could not validate', $response);
	}

	public function testApiControllerTooManyAttempts()
	{
		// $this->seed('SettingsSeeder');

		$settings = Setting::find(1);
		$settings->account_disabled_after_x_failed_attempts = 1;
		$settings->save();

		$this->assertEquals(0, $this->app_client->failed_login_count);
		$response = $this->action('GET', 'ApiController@validate', 
			array(
				'email' => $this->app_client->email,
				'password' => 'wrong'
			)
		);
		$this->assertEquals(1, Client::all()->first()->failed_login_count);

		// even correct password still return "too many failed login attempts" (account is locked)
		$response = $this->action('GET', 'ApiController@validate', 
			array(
				'email' => $this->app_client->email,
				'password' => $this->app_client->temp_pass
			)
		);
		$this->assertJsonErrorEquals('too many failed login attempts', $response);
	}
}
