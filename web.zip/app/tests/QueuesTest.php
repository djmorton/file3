<?php

class QueuesTest extends TestCase {
    
    public function setUp()
    {
        
        parent::setUp();

        Artisan::call('migrate:refresh');
        Artisan::call('db:seed');

    }

    public function addQueueItems()
    {
        $dt = new DateTime();

        $dt->sub(date_interval_create_from_date_string('2 days'));
        FirewallQueue::create(array('challenge_id'=>1,'ip_address'=>'127.0.0.1', 'open_or_close'=>'open','gotime'=>$dt));

        $dt->add(date_interval_create_from_date_string('4 days'));
        FirewallQueue::create(array('challenge_id'=>1,'ip_address'=>'127.0.0.1', 'open_or_close'=>'open','gotime'=>$dt));

    }

    public function testPending()
    {
        $this->addQueueItems();

        $all = FirewallQueue::all();
        $this->assertEquals($all->count(), 2);

        $pending = FirewallQueue::pending();
        $this->assertEquals($pending->count(), 1);
    }

    public function testProcessOpenJob()
    {
        // setup a pending job
        $dt = new DateTime();
        $dt->sub(date_interval_create_from_date_string('2 days'));
        FirewallQueue::create(array('challenge_id'=>1,'ip_address'=>'127.0.0.1', 'open_or_close'=>'open','gotime'=>$dt));

        $job = FirewallQueue::pending()->first();
        $job->processJob();

        $updated_job = FirewallQueue::find($job->id);
        $this->assertEquals('close', $updated_job->open_or_close);

        // TODO test date is set ahead correctly.
    }

    public function testProcessCloseJob()
    {
        // setup a pending job
        $job = FirewallQueue::makeNewJob(1, '127.0.0.1');
        $job->open_or_close = 'close';
        $job->processJob();

        // job should be deleted
        $job = FirewallQueue::find($job->id);
        $this->assertNull($job);
    }

    public function testMakeNewJob()
    {
        $job = FirewallQueue::makeNewJob(1, '127.0.0.1');
        $this->assertEquals(FirewallQueue::all()->count(), 1);
    }


	public function testResultIsOk()
	{
		$job = FirewallQueue::makeNewJob(1, '127.0.0.1');
		
		$add = 'netsh advfirewall firewall add rule name="DUMMY TEST RULE" dir=in action=block protocol=TCP localport=8000';
		$remove = 'netsh advfirewall firewall delete rule name="DUMMY TEST RULE"';
		$result = shell_exec($add);
		
		$r = $job->resultIsOk($result);
		$this->assertEquals(true, $r);
		
		$job->open_or_close = 'close';
		$result = shell_exec($remove);
		$r = $job->resultIsOk($result);
		$this->assertEquals(true, $r);
	}

}
