<?php

class ClientModelTest extends TestCase {
	
	public function setUp()
	{
		
		parent::setUp();

		Artisan::call('migrate:refresh');

		$this->app_client = Client::create(array(
			'email' => 'client_alpha@quaranta.com',
			'first_name' => 'Client',
			'last_name' => 'Alpha',
		));
		$this->app_client->save();
	}

	public function testClientHasDefaultTempPassValue()
	{
		$this->assertNotEmpty($this->app_client->temp_pass);
	}
}
