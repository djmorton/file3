<?php

class ChallengeApiControllerTest extends TestCase {
	
	/*
	** Setup
	*/
	protected $app_client;

	public function setUp()
	{
		
		parent::setUp();

		$this->seed();
		$this->seed('TestDataSeeder');

		$this->setting = Setting::find(1);

		$this->app_client = Client::find(1);
		// Client's first device hasn't been enrolled yet
		// Client's second device has been enrolled, but not approved

		$device = $this->app_client->devices->find(1);

		// generate a new private/public key pair & csr
		$privKey = new Crypt_RSA();
		$privKey->loadKey('-----BEGIN RSA PRIVATE KEY-----
MIICXgIBAAKBgQDOY4XYPdDdjiw6vgLGL5P9WY6c6qFUmF/WJdb7VSlWBmCqfgft
OwCdS1bMvK8MpUWFl5P0RvOQe7e6CwALufBwdtdNxzD2fPiJLKd9qCXrNCmk0Gc7
mOtnMaQagoguiMTDkZKp5QTYBZmJw2wVdD4VqOQAD1PhGOaTzZLsSdZXfQIDAQAB
AoGAG2rbiNQBb1qn49qCdNXfjjGmVpB8LnLwPFBvju42cmVLfyqvSTkO26vP/p0h
kLJTRNbTmAkQPy/oQttGPh3ijlkKxfVWOrSHLHp1y4dc+m/Juiz4t8ESGBPl1Y+K
9ETOzVBuXnAsx9bXTLUNCYA2M0T7NcgLFSI2YIJmFOFiffMCQQDbc3Zt83dOjj2G
JlE9l/kpnA51BjQoubv+8jRJxfCi5fdn1W4e/NSRFFyhTZvT5Q1PC8PkuRybFZ20
B2JPbgY3AkEA8MMi1111THrcHYubhWuNlTl6G66stlA5s7bjtNNSToTFr+0HhAML
Mdsz1kSbMuxLqERVLqHPQnBF4rK92Tz16wJBANhFGyLSvPKLFbD+VDQacLCEHm9P
9Nlp6g8gDU3jJ/qyHjeTTFp3mtl7sqo4/Og/pPUQyDbCA6IHFItWd5mF+dMCQQCg
f+V1Hsd4cZrVU2Ec42MiLIvbcmmOrBKbXHuV6x4+W8KRkfjlp0XKOa/n0hqIKwAQ
r2T9zj6lssTT6IYpELt7AkEAqC/TxX7Awdqpgr3WSTkfY3e8Z3lICjIoZt72eOXs
VbtHTYfZD/JYMIQ3X1HYf7W+POm/pbyKKGda5MJXPWNHMA==
-----END RSA PRIVATE KEY-----');
		$this->privKey = $privKey;

		$x509 = new File_X509();
		$x509->setPrivateKey($privKey);
		$x509->setDNProp('id-at-organizationName', 'phpseclib demo cert');

		$csr = $x509->signCSR();
		$csr_pem = $x509->saveCSR($csr);

		// set the device's csr_pem to our generated one (so we have the private key handy)
		$device->ssl_csr = $csr_pem;

		// generate client nonce
		$client_nonce = openssl_random_pseudo_bytes(256);
		$client_nonce = hash_hmac('sha256', $client_nonce, 'quaranta_nonce');
		$this->client_nonce = $client_nonce;

		// sign the device's CSR, save it
		$device_cert = $device->sign_csr($this->setting->server_ssl_cert, $this->setting->server_ssl_privkey, 365);
		$device->ssl_cert 			=	$device_cert['cert'];
		$device->ssl_cert_expires 	= 	$device_cert['expires'];
		$device->approved = true;

		$device->save();

		$this->device = $device;
	}

	/*
	** Custom Assertions
	*/

	public function assertJsonErrorEquals($want, $response)
	{
		$json = json_decode($response->getContent());
		return $this->assertEquals($want, $json->error);
	}

	/*
	**  Assertions
	*/
	public function testSeededClientIsValid()
	{
		$this->assertInstanceOf('Client', $this->app_client);
	}

	public function testChallengeStoreErrorIfClientDeleted()
	{
		$this->app_client->delete();
		$this->app_client->cascade_delete();

		/*
		** PART 1 :: Challenge creation/store
		*/
		$ip_address = '127.0.0.1';
		$client = $this->app_client;
		$device = $this->device;

		// get server public key from settings
		$server_public_key 	= new Crypt_RSA();
		$server_public_key->loadKey($this->setting->server_ssl_pubkey);

		// construct client payload
		$payload = json_encode(array(
			'email'			=> $client->email,
			'device_id' 	=> $device->device_id,
			'record_id'     => $device->id,
			'ip_address' 	=> $ip_address,
			'nonce'			=> $this->client_nonce
		));

		// First, encrypt using AES
		$cipher = new Crypt_AES(); 
		$response_key = openssl_random_pseudo_bytes(32);
		$response_iv = openssl_random_pseudo_bytes(16); // forge limitation
		$cipher->setKeyLength(256);
		$cipher->setKey($response_key);
		$cipher->setIV($response_iv);

		// encrypt the payload using AES
		$encrypted_payload = $cipher->encrypt($payload);

		// encrypt the AES key using server public RSA key
		$encrypted_key = $server_public_key->encrypt($response_key);

		$response = $this->action('POST', 'ChallengeApiController@store', 
			array(
				'payload' => base64_encode($encrypted_payload),
				'key' 		=> base64_encode($encrypted_key),
				'iv' 		=> base64_encode($response_iv)
			)
		);

		$this->assertJsonErrorEquals('device not found by device_id', $response);
	}
	
	public function testChallengeStoreUpdate()
	{
		/*
		** PART 1 :: Challenge creation/store
		*/
		$ip_address = '127.0.0.1';
		$client = $this->app_client;
		$device = $this->device;

		// get server public key from settings
		$server_public_key 	= new Crypt_RSA();
		$server_public_key->loadKey($this->setting->server_ssl_pubkey);

		// construct client payload
		$payload = json_encode(array(
			'email'			=> $client->email,
			'device_id' 	=> $device->device_id,
			'record_id'     => $device->id,
			'ip_address' 	=> $ip_address,
			'nonce'			=> $this->client_nonce
		));
		
		// First, encrypt using AES
		$cipher = new Crypt_AES(); 
		$response_key = openssl_random_pseudo_bytes(32);
		$response_iv = openssl_random_pseudo_bytes(16); // forge limitation
		$cipher->setKeyLength(256);
		$cipher->setKey($response_key);
		$cipher->setIV($response_iv);

		// encrypt the payload using AES
		$encrypted_payload = $cipher->encrypt($payload);

		// encrypt the AES key using server public RSA key
		$encrypted_key = $server_public_key->encrypt($response_key);

		// pass the payload to the challenge controller's STORE API
		$response = $this->action('POST', 'ChallengeApiController@store', 
			array(
				'payload' 	=> base64_encode($encrypted_payload),
				'key' 		=> base64_encode($encrypted_key),
				'iv' 		=> base64_encode($response_iv)
			)
		);

		$response = json_decode($response->getContent());

		// it will be base64_encoded
		$encrypted_payload = base64_decode($response->payload);
		$aes_key = base64_decode($response->key);
		$aes_iv  = base64_decode($response->iv);

		// decrypt the provided AES key (encrypted using server's public RSA key)
		$decrypted_key = $this->privKey->decrypt($aes_key);

		// decrypt using provided AES key
		$aes = new Crypt_AES();
		$aes->setKey($decrypted_key);
		$aes->setIV($aes_iv);

		$payload = $aes->decrypt($encrypted_payload);

		// we successfully decoded the payload
		$this->assertNotEmpty($payload);

		// json_decode the payload
		$payload = json_decode($payload);

		// we got back the client nonce we expected
		$this->assertEquals($this->client_nonce, $payload->client_nonce);

		// we got back a nonce from the server
		$this->assertNotEmpty($payload->server_nonce);

		// we received a challenge id
		$this->assertNotEmpty($payload->challenge_id);

		/*
		** PART 2 :: Challenge/update
		*/

		// construct client payload
		$client_payload = $server_public_key->encrypt($payload->server_nonce);

		$response = $this->action('PUT', 'ChallengeApiController@update', 
			array(
				'challenge' => $payload->challenge_id,
				'payload' => base64_encode($client_payload)
			)
		);

		$response = json_decode($response->getContent());
		$this->assertEquals($response->error, false);
		$this->assertEquals($response->approved, true);
		$this->assertNotEmpty($response->redirect_url);

		/*
		** PART 3 :: Test firewall rules were written (windows only)
		*/

		$queue_jobs = FirewallQueue::pending();
		$this->assertEquals(1, $queue_jobs->count());
		
		Artisan::call('fque:process');
		
		$job = FirewallQueue::pending()->first();
		$this->assertEquals("close", $job->open_or_close);
		
		// force this job to be pending now
		$dt = new Datetime();
		$dt->sub(date_interval_create_from_date_string('2 days'));
		$job->gotime = $dt;
		$job->save();
		
		Artisan::call('fque:process');

		$job = FirewallQueue::pending()->first();
		$this->assertEquals(NULL, $job);
		
	}

	// TODO test if encrypted with wrong key
}
