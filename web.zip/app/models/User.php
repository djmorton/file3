<?php

use Illuminate\Auth\UserInterface;
use Illuminate\Auth\Reminders\RemindableInterface;

class User extends Eloquent implements UserInterface, RemindableInterface {

	protected $softDelete = true;
	protected $fillable = array('first_name', 'last_name', 'email');

	/**
	 * The database table used by the model.
	 *
	 * @var string
	 */
	protected $table = 'users';

	/**
	 * The attributes excluded from the model's JSON form.
	 *
	 * @var array
	 */
	protected $hidden = array('password');

	/**
	 * Get the unique identifier for the user.
	 *
	 * @return mixed
	 */
	public function getAuthIdentifier()
	{
		return $this->getKey('email');
	}

	/**
	 * Get the password for the user.
	 *
	 * @return string
	 */
	public function getAuthPassword()
	{
		return $this->password;
	}

	public function getDates()
	{
	    return array('created_at', 'updated_at', 'deleted_at', 'last_login_at', 'password_updated_at', 'disable_login_at');
	}

	/**
	 * Get the e-mail address where password reminders are sent.
	 *
	 * @return string
	 */
	public function getReminderEmail()
	{
		return $this->email;
	}

	public function setPreviousPasswordsAttribute($password)
	{	
		$pp = $this->previous_passwords;
		$pp[time()] = $password;
		$this->attributes['previous_passwords'] = base64_encode(serialize($pp));
	}

	public function getPreviousPasswordsAttribute($value)
	{
		if(empty($value))
			$value = Array();
		else
			$value = unserialize(base64_decode($value));

		ksort($value, SORT_NUMERIC);
		return array_reverse($value, true);
	}

	/**
	 * Get the user's full name
	 *
	 * @return string
	 */
	public function get_name()
	{
		return $this->get_attribute('first_name') . " " . $this->get_attribute('last_name');
	}

	public static function validate($input, $user = false)
	{
		$messages = array();
		$rules = array(
			'email'     		=> array('Required','Between:3,64','Email','Unique:users,email', 'Regex:/@(rbccm|rbc).com$/'),
			'first_name' 		=> 'Required|Min:2|Max:80|Alpha',
			'last_name' 		=> 'Required|Min:2|Max:80|Alpha',
			'new_password'		=> 'Confirmed|passmatch_previous',
			'current_password' 	=> 'RequiredWith:new_password'
		);
		$messages['passmatch'] = "Ooops! Incorrect password";
		$messages['passmatch_previous'] = "Ooops! You have used this password before";
		$messages['email.regex'] = 'Email domain must be rbccm.com or rbc.com';
		
		// validate_password_not_account_name
		$flag = Setting::get('validate_password_not_account_name');
		if( strtolower($flag) == "on" )
		{
			$rules['new_password'] .= "|Different:email";
			$messages['new_password.different'] = 'Password can\'t be the same a your Email.';
		}

		// validate_password_contains_one_letter
		$one_letter = Setting::get('validate_password_contains_one_letter');
		if( strtolower($one_letter) == "on" )
		{
			$rules['new_password'] .= "|Regex:/[A-z]/";
			$messages['new_password.regex'] = 'Password must contain at least one letter';
		}

		// validate_password_contains_one_number
		$one_number = Setting::get('validate_password_contains_one_number');
		if( strtolower($one_number) == "on" )
		{
			$rules['new_password'] .= "|Regex:/[1-9]/";

			if( $one_letter )
				$messages['new_password.regex'] .= " and one number";
			else
				$messages['new_password.regex'] = 'Password must contain at least one number';
		}

		// validate_password_contains_x_characters
		$x_characters = Setting::get('validate_password_contains_x_characters');
		if( $x_characters > 0 )
		{
			$rules['new_password'] .= "|Min:" . $x_characters;
			$messages['new_password.size'] = 'The new password must be ' . $x_characters . ' characters minimum';
		}

		// Validators specific to updates
		if($user)
		{
			$rules['email'][3] .= "," . $user->id;
			$rules['current_password'] .= '|passmatch:' . $user->id;
		}

		$v = Validator::make($input, $rules, $messages);
		return $v;
	}

}

// every successful login should reset failed_login_count
Event::listen('auth.login', function($user)
{
	$user->failed_login_count = 0;
	$user->save();
});

// if no password given, set a tempoary one
// also set default value for password_updated_at
User::creating(function($user)
{
	// $user->password_updated_at = time();
	if( empty($user->password) )
	{
		$user->password = str_random(16);
	}

});

// set password_updated_at whenever password is changed
User::updating(function($user)
{
	$dirty = $user->getDirty();
	if(isset($dirty['password']))
		$user->password_updated_at = time();
	
});


/* 
** Upon saving a password change, store a copy
** of the old password in previous_passwords
** attribute.
*/
User::saving(function($user)
{
	// bail if this is a brand new record
	if(empty($user->id))
		return;

	// get dirty attributes, check if password is among them
	$updated_attributes = $user->getDirty();
	if( isset($updated_attributes['password']) )
	{
		Log::info('password changing - updating previous_passwords');
		$user->previous_passwords = $user->password;
	}
});

/*
** Validates the given current password matches
** against the users existing password.
*/
Validator::extend('passmatch', function($attribute, $value, $parameters)
{	
	$user = User::findOrFail($parameters[0]);
	return Hash::check($value, $user->password);
});

/*
** Validates the newly provided password hasn't been used previously
**
*/
Validator::extend('passmatch_previous', function($attribute, $value, $parameters)
{
	$limit = Setting::get('validate_password_differs_from_last_x');

	// if set to zero, then checking against past passwords is off
	if($limit == '0')
		return true;

	$past_passwords = Auth::user()->previous_passwords;

	$match = true;
	$count = 0;
	foreach($past_passwords as $old_pass)
	{
		if ($count == $limit)
			break;

		if( Hash::check($value, $old_pass) )
		{
			return false;
		}

		$count++;
	}

	return true;
});

