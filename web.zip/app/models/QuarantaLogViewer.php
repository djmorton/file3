<?php

/**
* 
*/
class QuarantaLogViewer
{
	public $file_list = array();
	protected $path = false;
	public $contents = false;
	public $id = false;

	public static $filter = 'log.INFO';

	public function __construct()
	{
		$this->path = app_path().'/storage/logs';
		$files = scandir($this->path);
		$file_list = array();
		foreach ($files as $file)
		{
			if ($file !== '.' && $file !== '..' && $file !== '.gitignore' && !is_dir($file))
			{
				$file_list[$file] = $file;
			}
		}

		$this->file_list = $file_list;
	}

	public function load($date)
	{
		if ( !array_key_exists($date, $this->file_list) )
		{
			return false;
		}

		$this->id = $date;
		$this->contents = file($this->path . "/" . $this->file_list[$date]);
		return $this->contents;
	}

	public function filter($f)
	{
		QuarantaLogViewer::$filter = $f;
		
		if( !$this->contents )
			return array();

		return array_filter($this->contents, function($v){
			return strpos($v, QuarantaLogViewer::$filter);
		});
	}

}
