<?php

class Device extends Eloquent {
	protected $softDelete = true;

	protected $fillable = array('device_id', 'ssl_csr');

	public function client()
	{
		return $this->belongsTo('Client');
	}

	public function challenges()
	{
		return $this->hasMany('Challenge');
	}

	public function csr()
	{
		$csr = $this->getAttribute('ssl_csr');
		
		if (empty($csr)) {
			return false;
		}

		$subject = openssl_csr_get_subject($csr);
		// easily (but somewhat slow) convert a php array into a php object
		$object = json_decode(json_encode($subject), FALSE);
		return $object;

	}

	public function getApprovedAttribute($v)
	{
		return $v ? true : false;
	}

	public function setSslCertExpiresAttribute($value) {
    	$this->attributes['ssl_cert_expires'] = new DateTime($value);
	}

	// sets attribute value to integer as boolean 
	// columns in sqlite/mysql are just inters
	public function setApprovedAttribute($v)
	{
		if(in_array($v, array('1', 1, 'true', true, 'yes')))
			$this->attributes['approved'] = 1;
		else
			$this->attributes['approved'] = 0;
	}

	public function sign_csr($cert_pem, $key_pem, $lifespan)
	{
		if(empty($this->ssl_csr))
		{
			throw new Exception('Missing Device CSR');
			return false;
		}

		if(empty($cert_pem))
		{
			throw new Exception('Missing Server SSL Cert');
			return false;
		}

		if(empty($key_pem))
		{
			throw new Exception('Missing Server Private Key');
			return false;
		}

		// load client CSR
		$client_csr = new File_X509();
		$client_csr->loadCSR($this->ssl_csr);

		// server private key
		$server_key = new Crypt_RSA();
		$server_key->loadKey($key_pem);

		// load server's cert
		$server_cert = new File_X509();
		$server_cert->loadX509($cert_pem);
		$server_cert->setPrivateKey($server_key);
		// return $server_cert->getIssuerDN(true);

		$x509 = new File_X509();
		$x509->setStartDate('-1 day');
		$x509->setEndDate("+1 year");
		$x509->makeCA();

		$result = $x509->sign($server_cert, $client_csr);
		$signed_client_certificate = $x509->saveX509($result);

		// generate new client temp pass 
		$this->client->temp_pass = str_random(16);
		$this->client->save();

		return array(
			'cert' => $signed_client_certificate,
			'expires' => $result['tbsCertificate']['validity']['notAfter']['generalTime']
		);
	}


	public static function validate($input)
	{
		$rules = array(
			'approved'     	=> 'Required|In:0,1',
			// TODO validate ssl_csr, ssl_cert format
			// TODO validate that if approved is set, 
			// 		then ssl_cert and ssl_cert_expires
			// 		is set/valid date
		);

		$v = Validator::make($input, $rules);
		return $v;
	}
}

// set default value approved to false
Device::creating(function($device)
{
	$device->approved = false;
});
