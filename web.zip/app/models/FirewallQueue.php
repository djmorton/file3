<?php

class FirewallQueue extends Eloquent {
	protected $table = 'queues';
	protected $fillable = array('challenge_id', 'ip_address', 'gotime', 'open_or_close');

	protected $open_port_cmd 	= "netsh advfirewall firewall add rule name=\"%1\$s\" dir=in action=allow protocol=TCP localport=\"%2\$d,%3\$d\" remoteip=\"%4\$s\"";
	protected $close_port_cmd 	= "netsh advfirewall firewall delete rule name=\"%1\$s\"";

	public function scopePending($query)
	{
		$now = new DateTime();
		return $query->where('gotime', '<=', $now);
	}

	public function resultIsOk($result)
	{
		$ok = false;
		$result = explode("\n", $result);
		
		// open commands just return single line "ok."
		if($this->open_or_close == 'open' && $result[0] == "Ok.")
			$ok = true;

		// close command return "(x) rule added" then "ok."
		if($this->open_or_close == 'close' && $result[2] == "Ok.")
			$ok = true;

		return $ok;
	}

	static public function makeNewJob($challenge_id, $ip_address)
	{
		$now = new DateTime;
		$job = self::create(array(
			'challenge_id' 	=> $challenge_id, 
			'ip_address' 	=> $ip_address, 
			'open_or_close' => 'open',
			'gotime' 		=> $now
		));

		$cmd = "eventcreate /d \"{$ip_address}\" /t information /id 888 /so QuarantaQueue";
		shell_exec($cmd);

		return $job;
	}

	public function ruleName()
	{
		return "Quaranta Client {$this->ip_address} jobId {$this->id}";
	}

	public function processJob()
	{
		$fmp_server_port = Setting::get('fmp_server_port');
		$web_server_port = Setting::get('web_server_port');

		if ( $this->open_or_close == "open" )
		{
			$cmd = sprintf($this->open_port_cmd, $this->ruleName(), $fmp_server_port, $web_server_port, $this->ip_address);
			$result = shell_exec($cmd);

			Log::info('Open Port Attempt FMP', array('rule_name' => $this->ruleName(), 'cmd' => $cmd, 'result' => $result, 'gotime' => $this->gotime));

			// update job to be re-processed as a "close" type later
			if($this->resultIsOk($result) )
			{
				$this->open_or_close = "close";
				$new_gotime = new DateTime();
				$new_gotime->add(date_interval_create_from_date_string(Setting::get('minutes_open') . " minutes"));
				$this->gotime = $new_gotime;
				$this->save();
			}
		} 

		elseif ( $this->open_or_close == "close" )
		{
			$cmd = sprintf($this->close_port_cmd, $this->ruleName());
			$result = shell_exec($cmd);
			Log::info('Close Port Attempt', array('rule_name' => $this->ruleName(), 'cmd' => $cmd, 'result' => $result, 'gotime' => $this->gotime));

			// delete the job
			if($this->resultIsOk($result)) $this->delete();
		}
	}
}
