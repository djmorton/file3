<?php

class Setting extends Eloquent {

	protected $guarded = array();

	/**
	 * The database table used by the model.
	 *
	 * @var string
	 */
	protected $table = 'settings';
	protected static $settings = null;

	public static function get($value, $reload = false){
		if(!self::$settings || $reload)
			self::$settings = Setting::find(1);
		return self::$settings->$value;
	}


	public static function validate($input)
	{
		$rules = array(
			'fmp_redirect_url'     	=> 'Required|Url',
			'fmp_server_port' 		=> 'Required|Min:1|Max:65535|Numeric',
			'web_server_port' 		=> 'Required|Min:1|Max:65535|Numeric',
			'minutes_open' 			=> 'Required|Min:1|Max:999|Numeric',
			'email_subject'			=> 'Required|Min:2|Max:255',
			'logins_disabled_after' => 'Date',
			'account_disabled_after_x_days' => 'Required|Min:0|Max:365|Numeric'
		);

		$v = Validator::make($input, $rules);
		return $v;
	}

	public function email_body_parsed($client)
	{
		$values = array(
			'USER_FIRST_NAME' 		=> $client->first_name,
			'USER_LAST_NAME' 		=> $client->last_name,
			'USER_TEMP_PASS'		=> $client->temp_pass,
			'QUARANTA_EMAIL'		=> $this->support_email,
			'APP_DOWNLOAD_URL'		=> $this->app_download_url
		);
		$body = str_replace(array_keys($values), array_values($values), $this->email_body);
		return rawurlencode($body);
	}

	// ValidatePasswordNotAccountName
	public function getValidatePasswordNotAccountNameAttribute($value)
	{
		return ($value == "1") ? "On" : "Off";
	}

	public function setValidatePasswordNotAccountNameAttribute($value)
	{
		$this->attributes['validate_password_not_account_name'] = (in_array(trim($value), array('On', 'on'))) ? 1 : 0;
	}

	// ValidatePasswordContainsOneLetter
	public function getValidatePasswordContainsOneLetterAttribute($value)
	{
		return ($value == "1") ? "On" : "Off";
	}
	public function setValidatePasswordContainsOneLetterAttribute($value)
	{
		$this->attributes['validate_password_contains_one_letter'] = (in_array(trim($value), array('On', 'on'))) ? 1 : 0;
	}

	// ValidatePasswordContainsOneNumber
	public function getValidatePasswordContainsOneNumberAttribute($value)
	{
		return ($value == "1") ? "On" : "Off";
	}
	public function setValidatePasswordContainsOneNumberAttribute($value)
	{
		$this->attributes['validate_password_contains_one_number'] = (in_array(trim($value), array('On', 'on'))) ? 1 : 0;
	}

	// ValidatePasswordResetOnFirstLogin
	public function getValidatePasswordResetOnFirstLoginAttribute($value)
	{
		return ($value == "1") ? "On" : "Off";
	}
	public function setValidatePasswordResetOnFirstLoginAttribute($value)
	{
		$this->attributes['validate_password_reset_on_first_login'] = (in_array(trim($value), array('On', 'on'))) ? 1 : 0;
	}

	// validate debug mode
	public function getDebugModeAttribute($value)
	{
		return ($value == "1") ? "On" : "Off";
	}
	public function setDebugModeAttribute($value)
	{
		$this->attributes['debug_mode'] = (in_array(trim($value), array('On', 'on'))) ? 1 : 0;
	}
}