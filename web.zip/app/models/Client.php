<?php

class Client extends Eloquent {

	protected $fillable = array('first_name', 'last_name', 'email');

	protected $softDelete = true;

	/**
	 * The database table used by the model.
	 *
	 * @var string
	 */
	protected $table = 'clients';


	public static function validate($input, $client = false)
	{
		$unique_rule = 'Unique:clients,email';
		// Validators specific to updates
		if($client)
		{
			$unique_rule .= "," . $client->id;
		}

		$rules = array(
			'email'     	=> array('Required','Between:3,64','Email', 'Regex:/@(rbccm|rbc).com$/', $unique_rule),
			'first_name' 	=> 'Required|Min:2|Max:80|Alpha',
			'last_name' 	=> 'Required|Min:2|Max:80|Alpha',
		);


		$messages = array(
			'email.regex' => 'Email domain must be rbccm.com or rbc.com',
		);

		$v = Validator::make($input, $rules, $messages);
		return $v;
	}

	public function devices()
	{
		return $this->hasMany('Device');
	}

	public function full_name()
	{
		return "{$this->getAttribute('first_name')} {$this->getAttribute('last_name')}";
	}

	public function cascade_delete()
	{
		// delete client's devices
		foreach($this->devices as $device)
		{
			// delete device challenges
			foreach ($device->challenges as $challenge) {
				$challenge->delete();
			}
			$device->delete();
		}
	}

	public function hasApprovedDevice()
	{
		Log::info('running hasApprovedDevice');
		foreach($this->devices as $device)
		{
			Log::info('This device approved? ' . $device->approved);
			if($device->approved)
			{
				return true;
			}
		}
		return false;
	}
}

// upon creating a client, set a temporary 
// password to a random string.
Client::creating(function($client)
{
	$client->temp_pass = str_random(16);
});

Client::deleted(function($client)
{
	$client->cascade_delete();
});
