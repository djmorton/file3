<?php

class Challenge extends Eloquent {
	protected $softDelete = true;

	protected $fillable = array('device_id', 'ip_address', 'nonce');

	public function device()
	{
		return $this->belongsTo('Device');
	}

	public function getApprovedAttribute($v)
	{
		return $v ? true : false;
	}

	// sets attribute value to integer as boolean 
	// columns in sqlite/mysql are just inters
	public function setApprovedAttribute($v)
	{
		if(in_array($v, array('1', 1, 'true', true, 'yes')))
			$this->attributes['approved'] = 1;
		else
			$this->attributes['approved'] = 0;
	}
}
