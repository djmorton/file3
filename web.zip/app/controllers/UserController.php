<?php

class UserController extends \BaseController {

	// default layout
	protected $layout = 'layouts.main';

	/**
	 * Display a listing of the resource.
	 *
	 * @return Response
	 */
	public function index()
	{
		// $users = User::all();
		$users = User::withTrashed()->orderBy('deleted_at')->orderBy('last_name')->get();
		return View::make('user.index', array('users' => $users));
	}

	/**
	 * Show the form for creating a new resource.
	 *
	 * @return Response
	 */
	public function create()
	{
		$user = new User;
		return View::make('user.create', array('user' => $user));
	}

	/**
	 * Store a newly created resource in storage.
	 *
	 * @return Response
	 */
	public function store()
	{
		// collect form data
		$data = Input::only('first_name', 'last_name', 'email');
		
		// validate data
		$v = User::validate($data);
		if( $v->passes() )
		{
			$user = User::create($data);
			return Redirect::action('UserController@show', array($user->id))->with('success', 'User Created');
		} else {
			return Redirect::action('UserController@create')->withInput()->withErrors($v);
		}
	}

	/**
	 * Display the specified resource.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function show($id)
	{
		$user = User::findOrFail($id);
		return View::make('user.show', array('user' => $user));
	}

	/**
	 * Show the form for editing the specified resource.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function edit($id)
	{
		$user = User::findOrFail($id);

		if(Auth::user() != $user)
			App::abort(401, 'You are not authorized.');
		return View::make('user.edit', array('user' => $user));
	}

	/**
	 * Update the specified resource in storage.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function update($id)
	{
		$user = User::findOrFail($id);

		if(Auth::user() != $user)
			App::abort(401, 'You are not authorized.');

		// collect form data
		$data = Input::all();

		// validate data
		$v = User::validate($data, $user);
		if( $v->passes() )
		{	
			if($data['new_password'])
			{
				$user->password = Hash::make($data['new_password']);
			}

			$user->update($data);

			return Redirect::action('UserController@show', array($user->id))->with('success', 'User Updated');
		} else {
			return Redirect::action('UserController@edit', array($user->id))->withInput()->withErrors($v);
		}
	}

	/**
	 * Remove the specified resource from storage.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function destroy($id)
	{
		$user = User::findOrFail($id);
		$user->delete();
		return Redirect::action('UserController@index')->with('succes', 'User Account Suspended');
	}

}
