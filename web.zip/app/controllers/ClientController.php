<?php
use Illuminate\Support\MessageBag;
class ClientController extends \BaseController {

	/**
	 * Display a listing of the resource.
	 *
	 * @return Response
	 */
	public function index()
	{
		$clients = Client::withTrashed()->orderBy('deleted_at')->orderBy('last_name')->get();
		$setting = Setting::find(1);

		return View::make('client.index', array( 'clients' => $clients, 'setting' => $setting));
	}

	/**
	 * Show the form for creating a new resource.
	 *
	 * @return Response
	 */
	public function create()
	{
		$client = new Client;
		return View::make('client.create', array('client' => $client));
	}

	/**
	 * Store a newly created resource in storage.
	 *
	 * @return Response
	 */
	public function store()
	{
		// collect form data
		$data = Input::only('first_name', 'last_name', 'email');
		
		// validate data
		$v = Client::validate($data);
		if( $v->passes() )
		{
			$client = Client::create($data);
			return Redirect::action('ClientController@show', array($client->id))->with('create_success', 'Client Created');
		} else {
			return Redirect::action('ClientController@create')->withInput()->withErrors($v);
		}
	}

	/**
	 * Display the specified resource.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function show($id)
	{
		$client = Client::findOrFail($id);
		return View::make('client.show', array('client' => $client));
	}

	/**
	 * Show the form for editing the specified resource.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function edit($id)
	{
		$client = Client::findOrFail($id);
		return View::make('client.edit', array('client' => $client));
	}

	/**
	 * Update the specified resource in storage.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function update($id)
	{
		$client = Client::findOrFail($id);

		// collect form data
		$data = Input::all();

		// validate data
		$v = Client::validate($data, $client);
		if( $v->passes() )
		{	
			$client->update($data);
			return Redirect::action('ClientController@show', array($client->id))->with('success', 'Client Updated');
		} else {
			return Redirect::action('ClientController@edit', array($client->id))->withInput()->withErrors($v);
		}
	}

	/**
	 * Remove the specified resource from storage.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function destroy($id)
	{
		$client = Client::findOrFail($id);
		$client->delete();
		return Redirect::action('ClientController@index')->with('succes', 'Client Account Suspended');
	}

	protected function parse_batch($batch)
	{
		$lines = preg_split('/\r\n|\n|\r/', $batch);
		$array = array();
		
		foreach($lines as $line)
		{
			$array[] = explode(',', $line);
		}

		return $array;
	}

	/**
	 * Create, store multiple resources from a list
	 *
	 * @return Response
	 */
	public function batch()
	{
		$batch = Input::get('batch');
	
		$batch_contents = $this->parse_batch($batch);

		$new_clients = array();
		$fail_clients = array();

		foreach($batch_contents as $new_client)
		{
			$data =array(
					'first_name' => trim(@$new_client[0]),
					'last_name'  => trim(@$new_client[1]),
					'email'		 => trim(@$new_client[2])
			);

			$v = Client::validate($data);
			if( $v->passes() )
			{
				$new_client = Client::create($data);
				$new_clients[] = $new_client->id;
			} else {
				$data['errors'] = implode("<br />", $v->messages()->all());
				$fail_clients[] = $data;
			}
		}

		if(empty($fail_clients))
		{
			return Redirect::action('ClientController@index')->with('success', "Batch client import successful.");
		} else {
			Session::flash('batch_results', array('new_clients' => $new_clients, 'fail_clients' => $fail_clients));
			return Redirect::action('ClientController@report');
		}
		
	}

	public function report()
	{
		if(! $batch_results = Session::get('batch_results'))
		{
			return Redirect::action('ClientController@index');
		}

		if($batch_results['new_clients'])
		{
			$clients = Client::find($batch_results['new_clients'])->all();
		} else {
			$clients = array();
		}
		
		return View::make('client.report',  array('clients' => $clients, 'fail_clients' => $batch_results['fail_clients']));
	}

}
