<?php

class ChallengeApiController extends \BaseController {

	/**
	 * Store a newly created resource in storage.
	 *
	 * @return Response
	 */
	public function store()
	{
		// TODO remove this line
		// TODO move as much of this as possible into model
		$setting = Setting::findOrFail(1);
		$payload = base64_decode(Input::get('payload'));
		$aes_key = base64_decode(Input::get('key'));
		$aes_iv = base64_decode(Input::get('iv'));

		// get server private key
		$server_ssl_privkey = new Crypt_RSA();
		$server_ssl_privkey->loadKey($setting->server_ssl_privkey);
		$decrypted_key = $server_ssl_privkey->decrypt($aes_key);

		if($decrypted_key == false)
		{
			return Response::json(array('error' => 'could not decrypt payload key')); 
		}
		

		$aes = new Crypt_AES(); 
		$aes->setKey($decrypted_key);
		$aes->setIV($aes_iv);
		$decrypted_payload = $aes->decrypt($payload);
		
		
		if($decrypted_payload == false)
		{
			return Response::json(array('error' => 'could not decrypt payload')); 
		}
		
		// payload should be json encoded, decode it
		$decrypted_payload = json_decode($decrypted_payload);
		

		// get the device from the device id
		$device = Device::find($decrypted_payload->record_id);

		if( !$device ){
			return Response::json(array('error' => 'device not found by device_id'));
		}

		if( !$device->approved ){
			return Response::json(array('error' => 'device has not been approved'));
		}

		// check ip_address given matches request ip
		if( !Setting::get('debug_mode') && $decrypted_payload->ip_address != Request::getClientIp() )
		{
			return Response::json(array('error' => 'mismatched ip_address'));
		}
		
		// check user id matches
		if( $decrypted_payload->email != $device->client->email )
		{
			return Response::json(array('error' => 'mismatched user_id'));
		}

		if( strlen($decrypted_payload->nonce) < 16 )
		{
			return Response::json(array('error' => 'require valid nonce'));
		}

		$time = time();
		$rand = openssl_random_pseudo_bytes(256);

		$server_nonce = hash_hmac('sha256', $time . $rand, 'quaranta_nonce');

		// determine which ip address to use depending on the debug_mode flag
		if(Setting::get('debug_mode')) {
			$ip_address = Request::getClientIp();
		} else {
			$ip_address = $decrypted_payload->ip_address;
		}

		// create the new challenge
		$challenge = new Challenge(array(
			'ip_address' => $ip_address,
			'nonce' => $server_nonce
		));

		$device->challenges()->save($challenge);

		Log::info("Created Challenge ({$challenge->id}). [Client: {$device->client->email},Device: {$device->device_id}, IP: {$ip_address}]");

		// encrypt return payload with client public key
		$response_data = json_encode(array(
			'client_nonce' => $decrypted_payload->nonce,
			'server_nonce' => $server_nonce,
			'challenge_id' => $challenge->id
		));
		
		
		// First, encrypt using AES
		$cipher = new Crypt_AES(); 
		$response_key = openssl_random_pseudo_bytes(32);
		$response_iv = openssl_random_pseudo_bytes(16); // forge limitation
		$cipher->setKeyLength(256);
		$cipher->setKey($response_key);
		$cipher->setIV($response_iv);
		
		$encrypted_payload = $cipher->encrypt($response_data);
		// Now, encrypt the key using RSA

		// load client public key
		$x509 = new File_X509();
		$client_cert = $x509->loadX509($device->ssl_cert);

		// get client public key from cert
		$client_public_key 	= new Crypt_RSA();
		$client_public_key->loadKey($client_cert['tbsCertificate']['subjectPublicKeyInfo']['subjectPublicKey']);
		

		$encrypted_key = $client_public_key->encrypt($response_key);

		// return our encrypted payload
		return Response::json( array('error' => false, 
			'payload' => base64_encode($encrypted_payload),
			'key' => base64_encode($encrypted_key),
			'iv' => base64_encode($response_iv)
		));
	}

	/**
	 * Update the specified resource in storage.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function update($id)
	{
		$setting = Setting::findOrFail(1);
		$payload = base64_decode(Input::get('payload'));

		// get server private key
		$server_ssl_privkey = new Crypt_RSA();
		$server_ssl_privkey->loadKey($setting->server_ssl_privkey);
		$decrypted_payload = $server_ssl_privkey->decrypt($payload);

		// get the challenge record from id
		$challenge = Challenge::find($id);

		if( !$challenge )
		{
			return Response::json(array('error' => 'challenge not found'));
		}

		if($decrypted_payload == false)
		{
			return Response::json(array('error' => 'could not decrypt payload')); 
		}

		
		//verify nonce
		if( $decrypted_payload != $challenge->nonce )
		{
			return Response::json(array('error' => 'server nonce does not match'));
			
		}

		$challenge->approved = true;
		$challenge->save();
		Log::info("Challenge Approved ({$challenge->id}). [Client: {$challenge->device->client->email},Device: {$challenge->device->device_id}, IP: {$challenge->ip_address}]");
		$job = FirewallQueue::makeNewJob($challenge->id, $challenge->ip_address);
		
		return Response::json( array(
			'error' => false,
			'approved' => $challenge->approved,
			'redirect_url' => $setting->fmp_redirect_url
		));
		
	}

}
