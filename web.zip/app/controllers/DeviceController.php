<?php
class DeviceController extends \BaseController {

	/**
	 * Display a listing of the resource.
	 *
	 * @return Response
	 */
	public function index()
	{
		//
	}

	/**
	 * Show the form for creating a new resource.
	 *
	 * @return Response
	 */
	public function create()
	{
		//
	}

	/**
	 * Store a newly created resource in storage.
	 *
	 * @return Response
	 */
	public function store()
	{
		//
	}

	/**
	 * Display the specified resource.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function show($id)
	{
		$device = Device::findOrFail($id);
		return View::make('device.show', array('device' => $device));
	}

	/**
	 * Show the form for editing the specified resource.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function edit($id)
	{
		//
	}

	/**
	 * Update the specified resource in storage.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function update($id)
	{
		$setting = Setting::findOrFail(1);

		$approved = Input::get('approved');
		$device = Device::findOrFail($id);

		// if we're approving a previously un-approved CSR
		if( !$device->approved && $approved == 'true' )
		{
			$device_cert = $device->sign_csr($setting->server_ssl_cert, $setting->server_ssl_privkey, 365);
			$device->ssl_cert 			=	$device_cert['cert'];
			$device->ssl_cert_expires 	= 	$device_cert['expires'];
			$device->approved = true;

			$success_message = 'CSR has been approved. Please notifiy the client.';
		} elseif( $device->approved && $approved == 'false' ) {
			$device->approved = false;
			$success_message = 'Access for this device has been revoked.';
		}

		$device->save();

		return Redirect::action('DeviceController@show', array($device->id))->with('success', 
			$success_message);
	}

	/**
	 * Remove the specified resource from storage.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function destroy($id)
	{
		//
	}

}