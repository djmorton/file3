<?php

class SettingController extends \BaseController {

	/**
	 * Display a listing of the resource.
	 *
	 * @return Response
	 */
	public function index()
	{
		$setting = Setting::findOrFail(1);
		return View::make('setting.index', array('setting' => $setting));
	}


	/**
	 * Update the specified resource in storage.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function update($id)
	{
		$setting = Setting::findOrFail($id);

		// collect form data
		$data = Input::all();
		
		// validate data
		$v = Setting::validate($data);
		if( $v->passes() )
		{
			$setting->update($data);
			return Redirect::action('SettingController@index')->with('success', 'Settings have been updated.');
		} else {
			return Redirect::action('SettingController@index')->withInput()->withErrors($v);
		}
	}

}