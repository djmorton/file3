<?php

class LoginController extends \BaseController {

	public function show()
	{
		if(Auth::check())
			return Redirect::to('/');

		return View::make('login.login');
	}

	public function login()
	{
		$userdata = array(
			'email' 	=> Input::get('email'),
			'password' 	=> Input::get('password')
		);

		// see if this account exists ... perform some sanity checks
		if( $user = User::where('email', Input::get('email'))->first() ) {
			if($r = $this->checkTooManyLoginAttempts($user))
				return $r;
			
			if($r = $this->checkAccountTooOld($user))
				return $r;
			
			if($this->checkAccountInactivity($user))
				return $r;
		}

		if ( Auth::attempt($userdata) )
		{
			// update user's last login
			$user = Auth::user();
			$user->last_login_at = time();
			$user->save();

			if($r = $this->checkForcePasswordReset($user))
				return $r;

			return Redirect::to('/');
		} else {
			$this->logAttempt($userdata);
			return Redirect::to('login')->with('login_errors', true);
		}
	}

	public function logout()
	{
		if(Auth::check())
			Auth::logout();
		return Redirect::to('/');
	}


	protected function checkForcePasswordReset($user)
	{
		$setting = Setting::get('pasword_resets_every_x_days');
		$now = new DateTime();
		$diff = $now->diff($user->password_updated_at);

		if($setting && $diff->days > $setting)
		{
			Log::info('User With Stale Password', array('user' => $user->toJson()));
			return Redirect::action('UserController@edit', array($user->id))->with('password_requires_reset', $diff->days);
		}
	}


	// * ON / OFF After user makes [X] failed attempts – default ON – 5 attempts
	protected function checkTooManyLoginAttempts($user)
	{
		if(Setting::get('account_disabled_after_x_failed_attempts') && $user->failed_login_count >= Setting::get('account_disabled_after_x_failed_attempts'))
		{
			Log::info('Disabled User Login Attempt: account_disabled_after_x_failed_attempts', array('user' => $user->toJson()));
			// $user->delete();
			return Redirect::to('login')->with('locked_failed_attempts', $user->failed_login_count);
		}
	}

	// * ON / OFF After using it for [X] days – default OFF
	protected function checkAccountTooOld($user)
	{
		
		if(Setting::get('account_disabled_after_x_days') != 0)
		{
			$now = new DateTime();
			$diff = $now->diff($user->created_at);
			
			if($diff->days > Setting::get('account_disabled_after_x_days'))
			{
				Log::info('Disabled User Login Attempt: account_disabled_after_x_days', array('days' => $diff->days, 'user' => $user->toJson()));
				// $user->delete();
				return Redirect::to('login')->with('account_expired', $diff->days);
			}
		}
	}

	// * ON / OFF After inactive for [X] days – default OFF
	protected function checkAccountInactivity($user)
	{
		
		if(Setting::get('account_disabled_after_x_days_inactivity') != 0){
			if($user->last_login_at)
			{
				$now = new DateTime();
				$diff = $now->diff($user->last_login_at);
				
				if($diff->days > Setting::get('account_disabled_after_x_days_inactivity'))
				{
					Log::info('Disabled User Login Attempt: account_disabled_after_x_days_inactivity', array('days' => $diff->days, 'user' => $user->toJson()));
					// $user->delete();
					return Redirect::to('login')->with('account_disabled_for_inactivity', $diff->days);
				}
			}
		}
	}


	protected function logAttempt($credentials)
	{
		Log::info('Failed Login Attempt', array('credentials' => $credentials));

		$user = User::where('email', $credentials['email'])->first();
		if( empty($user) )
			return;

		$user->failed_login_count++;
		$user->save();
	}

}