<?php

class ApiController extends \BaseController {
	/**
	 * Used to test SSL Cert, rediness of server. Returns basic info about server:
	 * api version, ip address
	 *
	 * @return Response
	 */
	public function index()
	{
		return Response::json(array(
			'api_version' => '1.0',
			'error' => false,
			)
		);
	}

	public function rules()
	{
		return Response::json(array(
			'error' => false,
			'rules' => array(
				'account_disabled_after_x_days' 			=> Setting::get('account_disabled_after_x_days'),
				'account_disabled_after_x_days_inactivity' 	=> Setting::get('account_disabled_after_x_days_inactivity'),
				'account_disabled_after_x_failed_attempts' 	=> Setting::get('account_disabled_after_x_failed_attempts'),
				'validate_password_not_account_name' 		=> Setting::get('validate_password_not_account_name'),
				'validate_password_contains_one_letter' 	=> Setting::get('validate_password_contains_one_letter'),
				'validate_password_contains_one_number' 	=> Setting::get('validate_password_contains_one_number'),
				'validate_password_reset_on_first_login' 	=> Setting::get('validate_password_reset_on_first_login'),
				'validate_password_contains_x_characters'	=> Setting::get('validate_password_contains_x_characters'),
				'validate_password_differs_from_last_x' 	=> Setting::get('validate_password_differs_from_last_x'),
				'pasword_resets_every_x_days' 				=> Setting::get('pasword_resets_every_x_days'),
			)
		));
	}

	public function validate()
	{
		$email		= Input::get('email');
		$temp_pass	= Input::get('password');

		$client = Client::where('email', $email)->first();

		// we do have a client with this email, not checking password yet.
		$attempt_limit = Setting::get('account_disabled_after_x_failed_attempts');

		if($client) {
			if($attempt_limit && $client->failed_login_count >= $attempt_limit)
			{
				Log::info('Too many login attempts for temporary password on client', array('client' => $client->toJson()));
				// $user->delete();
				return Response::json(array(
					'error' => 'too many failed login attempts',
					'request' => Input::all()
				)); 
			}

			if($client->temp_pass === $temp_pass)
			{
			
				return Response::json(array(
					'error' => false,
					'client_id' => $client->id
				));
			} else {
				$client->failed_login_count++;
				$client->save();
			}
		}

		return Response::json(array(
			'error' => 'could not validate',
			'request' => Input::all()
		));
	}

	public function log()
	{
		Log::info("Mobile Client Error: " . Input::get('error'));
		return Response::json(array(
			'error' => false,
			'logged' => Input::get('error')
		));
	}

}