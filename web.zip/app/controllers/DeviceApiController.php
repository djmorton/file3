<?php

class DeviceApiController extends \BaseController {

	/**
	 * Show the form for creating a new resource.
	 *
	 * @return Response
	 */
	public function store()
	{
		/*
		** Error checking / validting
		*/
		// $data = Input::only('email', 'password');
		$client = Client::where('email', Input::get('email'))->first();

		if(!$client)
		{
			return Response::json(array('error' => 'client not found by email', 'request_data' => Input::all()));
		}

		if( $client->temp_pass !== Input::get('password') )
		{
			return Response::json(array('error' => 'password mismatch', 'request_data' => Input::all()));
		}

		// check the CSR validity
		$ssl_csr = Input::get('ssl_csr');
		$x509 = new File_X509();
		$client_cert = $x509->loadCSR($ssl_csr);
		if( !$client_cert )
		{
			return Response::json(array('error' => 'valid CSR required', 'request_data' => Input::all()));
		}

		$device_id = $x509->getDNProp('OU');
		if( empty($device_id) )
		{
			return Response::json(array('error' => 'device ID required', 'request_data' => Input::all()));
		}

		// create record in db
		$device = new Device(array('device_id' => $device_id[0], 'ssl_csr' => $ssl_csr));
		$device = $client->devices()->save($device);
		
		return Response::json(array('error' => false, 
			'request_data' => Input::all(), 
			'client_id' => $client->id, 
			'device_record_id' => $device->id));
	}

	/**
	 * Display the specified resource.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function show($id)
	{
		$device = Device::find($id);

		if( !$device )
		{
			return Response::json(array('error' => 'device not found', 'request_data' => Input::all()));
		}

		return Response::json(array('error' => false, 
			'approved' 				=> $device->approved, 
			'ssl_cert' 				=> $device->ssl_cert,
			'ssl_cert_expires' 		=> $device->ssl_cert_expires
		));
	}

}
