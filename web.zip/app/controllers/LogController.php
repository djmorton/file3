<?php

class LogController extends \BaseController {

	/**
	 * Display a listing of the resource.
	 *
	 * @return Response
	 */
	public function index()
	{
		$logs = new QuarantaLogViewer();
		return View::make('log.index', array('logs' => $logs));
	}

	/**
	 * Display the specified resource.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function show($id)
	{
		$logs = new QuarantaLogViewer();
		$logs->load($id);

		return View::make('log.show', array('logs' => $logs));
	}

}