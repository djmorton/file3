<?php

use Illuminate\Console\Command;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Input\InputArgument;

class StoreDevice extends Command {

	/**
	 * The console command name.
	 *
	 * @var string
	 */
	protected $name = 'device:submit';

	/**
	 * The console command description.
	 *
	 * @var string
	 */
	protected $description = 'Used to generate dummy device records for clients.';

	/**
	 * Create a new command instance.
	 *
	 * @return void
	 */
	public function __construct()
	{
		parent::__construct();
	}

	/**
	 * Execute the console command.
	 *
	 * @return void
	 */
	public function fire()
	{
		$client = Client::where('email', $this->argument('client_email'))->first();
		if (!$client){
			$this->error('Could not find client by email: ' . $this->argument('client_email'));
		}

		$device_id = '2b6f0cc904d137be2e1730235f5664094b831186';
		$privKey = new Crypt_RSA();
		$privKey->loadKey('-----BEGIN RSA PRIVATE KEY-----
MIICXgIBAAKBgQDOY4XYPdDdjiw6vgLGL5P9WY6c6qFUmF/WJdb7VSlWBmCqfgft
OwCdS1bMvK8MpUWFl5P0RvOQe7e6CwALufBwdtdNxzD2fPiJLKd9qCXrNCmk0Gc7
mOtnMaQagoguiMTDkZKp5QTYBZmJw2wVdD4VqOQAD1PhGOaTzZLsSdZXfQIDAQAB
AoGAG2rbiNQBb1qn49qCdNXfjjGmVpB8LnLwPFBvju42cmVLfyqvSTkO26vP/p0h
kLJTRNbTmAkQPy/oQttGPh3ijlkKxfVWOrSHLHp1y4dc+m/Juiz4t8ESGBPl1Y+K
9ETOzVBuXnAsx9bXTLUNCYA2M0T7NcgLFSI2YIJmFOFiffMCQQDbc3Zt83dOjj2G
JlE9l/kpnA51BjQoubv+8jRJxfCi5fdn1W4e/NSRFFyhTZvT5Q1PC8PkuRybFZ20
B2JPbgY3AkEA8MMi1111THrcHYubhWuNlTl6G66stlA5s7bjtNNSToTFr+0HhAML
Mdsz1kSbMuxLqERVLqHPQnBF4rK92Tz16wJBANhFGyLSvPKLFbD+VDQacLCEHm9P
9Nlp6g8gDU3jJ/qyHjeTTFp3mtl7sqo4/Og/pPUQyDbCA6IHFItWd5mF+dMCQQCg
f+V1Hsd4cZrVU2Ec42MiLIvbcmmOrBKbXHuV6x4+W8KRkfjlp0XKOa/n0hqIKwAQ
r2T9zj6lssTT6IYpELt7AkEAqC/TxX7Awdqpgr3WSTkfY3e8Z3lICjIoZt72eOXs
VbtHTYfZD/JYMIQ3X1HYf7W+POm/pbyKKGda5MJXPWNHMA==
-----END RSA PRIVATE KEY-----');

		$x509 = new File_X509();
		$x509->setPrivateKey($privKey);
		$x509->setDNProp('id-at-organizationName', 'phpseclib demo cert');
		$x509->setDNProp('emailAddress', 'test@foo.ca');
		$x509->setDNProp('CN', 'phpseclib demo cert');
		$x509->setDNProp('L', 'Vancouver');
		$x509->setDNProp('ST', 'BC');
		$x509->setDNProp('C', 'CA');
		$x509->setDNProp('OU', $device_id);

		$csr = $x509->signCSR();
		$csr_pem = $x509->saveCSR($csr);

		$device = new Device(array('device_id' => $device_id, 'ssl_csr' => $csr_pem));
		$device = $client->devices()->save($device);

		$this->info('New device added.');
	}

	/**
	 * Get the console command arguments.
	 *
	 * @return array
	 */
	protected function getArguments()
	{
		return array(
			array('client_email', InputArgument::REQUIRED, 'Client Email.')
		);
	}

	/**
	 * Get the console command options.
	 *
	 * @return array
	 */
	protected function getOptions()
	{
		return array(
		);
	}

}