<?php

use Illuminate\Console\Command;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Input\InputArgument;

class PasswordReset extends Command {

	/**
	 * The console command name.
	 *
	 * @var string
	 */
	protected $name = 'password:reset';

	/**
	 * The console command description.
	 *
	 * @var string
	 */
	protected $description = 'Resets specified admin\'s password to a temporary password.';

	/**
	 * Create a new command instance.
	 *
	 * @return void
	 */
	public function __construct()
	{
		parent::__construct();
	}

	/**
	 * Execute the console command.
	 *
	 * @return void
	 */
	public function fire()
	{
		$admin_email = $this->argument('admin_email');
		$user = User::where('email', $admin_email)->first();

		if(!$user)
		{
			$this->error('Could not find an Admin with that email/login');
			return;
		}

		$chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
		$new_password = substr(str_shuffle($chars),0,12);

		$user->password = Hash::make($new_password);
		$user->failed_login_count = 0;
		Log::info('Password reset via commandline.');
		$user->save();

		$this->info('New temporary password will be: ' . $new_password);
	}

	/**
	 * Get the console command arguments.
	 *
	 * @return array
	 */
	protected function getArguments()
	{
		return array(
			array('admin_email', InputArgument::REQUIRED, 'Admin email/login to reset.'),
		);
	}

	/**
	 * Get the console command options.
	 *
	 * @return array
	 */
	protected function getOptions()
	{
		return array(
		);
	}

}
