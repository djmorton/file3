<?php

use Illuminate\Console\Command;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Input\InputArgument;

class FQue extends Command {

	/**
	 * The console command name.
	 *
	 * @var string
	 */
	protected $name = 'fque:process';

	/**
	 * The console command description.
	 *
	 * @var string
	 */
	protected $description = 'Will check the firewall queue for pending job items. Job items can either be to add or remove a firewall rule';

	/**
	 * Create a new command instance.
	 *
	 * @return void
	 */
	public function __construct()
	{
		parent::__construct();
	}

	public function listPending()
	{
		// Illuminate\Database\Eloquent\Collection
		$que = FirewallQueue::pending()->get();
		$this->displayQue($que);
	}

	public function listAll()
	{
		// Illuminate\Database\Eloquent\Collection
		$que = FirewallQueue::all();
		$this->displayQue($que);
	}

	public function displayQue($que)
	{
		if($que)
		{
			echo "\n";

			$que->each(function($job){
				echo "JobId:{$job->id} {$job->ruleName()} challenge_id:{$job->challenge_id} ip_address:{$job->ip_address} gotime:{$job->gotime}\n";
			});
			echo "Total: {$que->count()}\n";
			return;
		}
	}

	/**
	 * Execute the console command.
	 *
	 * @return void
	 */
	public function fire()
	{
		if ($this->option('list-pending')) {
			return $this->listPending();
		} 
		elseif($this->option('list-all'))
		{
			return $this->listAll();
		}

		// process the que
		$queue_jobs = FirewallQueue::pending()->get();
		
		if(!$queue_jobs->count() > 0) return;
		
		Log::info("Fque processing {$queue_jobs->count()} pending jobs");
		$queue_jobs->each(function($job){
			$job->processJob();
		});
	}

	/**
	 * Get the console command arguments.
	 *
	 * @return array
	 */
	protected function getArguments()
	{
		return array(
		);
	}

	/**
	 * Get the console command options.
	 *
	 * @return array
	 */
	protected function getOptions()
	{
		return array(
			array('list-pending', 	null, InputOption::VALUE_NONE, 'lets you just list the pending queued jobs'),
			array('list-all',		null, InputOption::VALUE_NONE, 'lets you just list all the queued jobs')
		);
	}

}