<?php

use Illuminate\Console\Command;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Input\InputArgument;

class ApproveAppleAccount extends Command {

	/**
	 * The console command name.
	 *
	 * @var string
	 */
	protected $name = 'apple:approve';

	/**
	 * The console command description.
	 *
	 * @var string
	 */
	protected $description = 'Used to approve apples app store testing requirements.';

	/**
	 * Create a new command instance.
	 *
	 * @return void
	 */
	public function __construct()
	{
		parent::__construct();
	}

	/**
	 * Execute the console command.
	 *
	 * @return void
	 */
	public function fire()
	{
		$client = Client::where('email', 'apple@rbc.com')->first();
		if (!$client) {
			return false;
		}


		$setting = Setting::findOrFail(1);
		$device = $client->devices->last();

		if (!$device) {
			Log::info("No pending device record found for apple@rbc.com");
			return false;
		}

		$device_cert = $device->sign_csr($setting->server_ssl_cert, $setting->server_ssl_privkey, 365);
		$device->ssl_cert 			=	$device_cert['cert'];
		$device->ssl_cert_expires 	= 	$device_cert['expires'];
		$device->approved = true;

		$device->save();
		Log::info("Approved device record on apple@rbc.com account");

	}

	/**
	 * Get the console command arguments.
	 *
	 * @return array
	 */
	protected function getArguments()
	{
		return array(
		);
	}

	/**
	 * Get the console command options.
	 *
	 * @return array
	 */
	protected function getOptions()
	{
		return array(
		);
	}

}