<?php

	require_once '../boris/lib/autoload.php';
	require_once 'bootstrap/autoload.php';
	require_once 'bootstrap/start.php';
	$boris = new \Boris\Boris('quaranta> ');
	$boris->start();
